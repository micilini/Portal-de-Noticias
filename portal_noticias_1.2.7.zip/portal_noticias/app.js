//Depois de ajustar a home do nosso website chegou a hora de ajustar o nosso formulario de noticias, mas espera um pouco will, a gente ja tinha feito isso antes ?

//Sim mas com o layout antigo, agora vamos portabilizar para que isso seja feito no layout novo =) Então meio que se voce for verificar na aula anterior o formulario não estava funcionando, então agora chegou a hora de coloca-lo para funcionar!

//Nesse projeto a gente vai trabalhar apenas com:

/*

* formulario_add_noticia.ejs

A primeira coisa que configurei no nosso arquivo formulario_add_noticia.ejs foi criar um action no formulario de lá para que ele possa disparar para o caminho salvar, para isso eu adicionei o seguinte comando no formulario:

action="/noticias/salvar" method="post"

A segunda coisa foi arrumar as mensagens de validação caso alguma coisa der errado, então usei aquela mesma estrutura dos if para verificar se a variavel validacao esta cheia e se estiver mostrar as mensagens de erros.

*/


var app = require('./config/server');

app.listen(3000, function(){
    console.log("Servidor ON");
});
