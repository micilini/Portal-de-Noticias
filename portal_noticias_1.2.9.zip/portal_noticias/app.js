//O objetivo desta aula agora é arrumar aquela noticia estatica quando a gente clica em um dos links de noticias, até porque quando a gente clica em um link desses, a gente quer ver o que ? A noticia que a gente clicou é claro!

//Então antes de mais nada devemos entender que quando a gente pega uma noticia no banco de dados usando a função getNoticias a gente esta trazendo todos os campos da nossa tabela noticia e esta reenviando esses dados para seus respectivos arquivos .ejs e de lá eles estão pegando esses parametros e fazendo o que ?

//Isso mesmo, printando na tela.

//É claro que tem alguns parametros que estão sendo retornados mas que não estamos usando, voce sabe quais são eles ?

//São id_noticias e uma coluna de data lá... que eu não sei qual é o nome agr...

//Mas tenha em mente que essas duas colunas apesar de não estarem sendo mostradas na tela, elas estão retornando sim!

/*

Sendo assim, vamos ter que utilizar a coluna id_noticias que está sendo retornada pra gente nos arquivos home.ejs e noticias.ejs, tudo que a gente vai ter que fazer é atualizar os arquivos mais espeficiamente os links, sabe aonde existe href="noticia", então vamos atualizar para que alem de chamar esta tela, ele envie um parametro, para criar parametros na url a gente precisa fazer da seguinte forma:

1- Colocar um ponto de interrogação (?) {Isso vai dizer ao navegador que estamos enviando um parametro}
2- Em seguida informar o nome desse parametro (chave) {Imagina isso como uma variavel que armazena valores ok ?}
3- E por fim adicionar o sinal de igual (=) e depois dele o valor (valor) {Isso diz que estamos atribuindo na 'variavel' um determinado valor}

Por exemplo:

noticia?id_noticias=2

E foi exatamente isso que iremos fizemos! Menos a parte do 2 é claro... no local de 2 falamos pro EJS printar o valor contido dentro daquela coluna assim como fizemos com as colunas titulo, autor, resumo e afins.

De uma olhada nesses 2 arquivos (home.ejs e noticias.ejs) eles estão atualizados agora!

Agora chegou a parte de atualizarmos o controller chamado noticia.js para que ele consiga pegar esse parametro enviar para o model e assim pegar o id que o nosso usuario clicou e mostrar a noticia certa.

Te vejo no controller noticia.js

*/

var app = require('./config/server');

app.listen(3000, function(){
    console.log("Servidor ON");
});
