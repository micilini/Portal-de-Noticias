module.exports.noticias = function(application, req, res){
    var connection = application.config.dbConnection();
    var noticiasModel = new application.app.models.NoticiasDAO(connection);

    noticiasModel.getNoticias(function(error, result){
        res.render('noticias/noticias', { noticias : result });
    });
}

module.exports.noticia = function(application, req, res){
    var connection = application.config.dbConnection();
    var noticiasModel = new application.app.models.NoticiasDAO(connection);

    var id_noticia = req.query;//Se quisermos pegar os parametros enviando via URL como fizemos nos arquivos das views, só existe um local aonde podemos encontra-lo.. aonde ? Dentro da variavel req, lá podemos encontrar inumeras requisições e parametros que são enviados, o caso os nossos parametros foram enviados por URL, então automaticamente a gente reconhece que eles são do tipo GET, e esses parametros ficam dentro da chave query do request, nesse caso basta usarmos o comando: req.query para recuperarmos esses valores! O bom do NODEJS e do express é que eles ja vem em formato JSON da seguinte forma: {'id_noticias' : 2}

    //Perfeito agora que ja temos salvo o valor da noticia que queremos selecionar para depois mostrar na tela, basta enviarmos essa variavel lá pro noticiasDAO e de lá vamos inserie este valor no nosso banco de dados:

    noticiasModel.getNoticia(id_noticia, function(error, result){//Aqui eu precisei enviar mais um parametro pro getNoticia que é o id da noticia que queremos que ele selecione no banco de dados... Te vejo agora dentro do arquivo noticiasdao.js
        res.render('noticias/noticia', { noticia : result });
    });
}
