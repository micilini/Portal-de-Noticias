function NoticiasDAO(connection){
    this._connection = connection;
}

NoticiasDAO.prototype.getNoticias = function(callback){
    this._connection.query('SELECT * FROM noticias ORDER BY data_criacao DESC', callback);
}

NoticiasDAO.prototype.getNoticia = function(id_noticia, callback){//Lembrando que agora precisamos recuperar o id da noticia aqui dentro da nossa função
    this._connection.query('SELECT * FROM noticias WHERE id_noticias = ' + id_noticia.id_noticias, callback);//Aqui no caso eu fiz uma concatenação em javascript aonde eu peguei a variavel que continha o id da noticia e joguei ela junto da string!

//Experimente agora acessar a home ou noticias, e tente clicar em um dos links! Tooop não é mesmo =)

}

NoticiasDAO.prototype.salvarNoticia = function(noticia, callback){
    this._connection.query('INSERT INTO noticias SET ?', noticia, callback);
}

NoticiasDAO.prototype.get5UltimasNoticias = function(callback){
    this._connection.query('SELECT * FROM noticias ORDER BY data_criacao DESC LIMIT 5', callback);
}

module.exports = function(){
    return NoticiasDAO;
}
