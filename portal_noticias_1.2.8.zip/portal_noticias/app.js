//Show de bola, ja ajustamos a nossa home, o nosso formulario de inclusão de noticias, agora o que falta ajustar ? A pagina de noticias é claro rs!

//Aqui nesta aula a gente vai atualizar o arquivo noticias.ejs para que ele trabalhe com os resultados que ja estao vindo por parametro atraves dos controllers e das rotas.

//Eu tambem fiz uma pequena modificação no arquivo noticiasDAO.js para que a função chamada getNoticias não so me retorne todas as noticias, mas em formato decrescente usando o order by assim a gente consegue visualizar as noticias mais recentes primeiro e as mais antigas depois.

//Perfeito, a segunda coisa que fizemos de alteração foi o seguinte, quando a gente acessa localhost:3000/noticias a gente sabe que cada bloco de noticias daquele na verdade é um link que assim quando clicado deverá redirecionar o usuario para a tela de noticias, infelizmente o usuario estava sendo redirecionado para noticia.html, tanto no arquivo noticias.ejs quanto no home.ejs (Sim lá tambem existia esse link).

//Por enquanto não vamos criar nenhuma rota para que assim que o usuario clique na noticia ele visualize especificamente aquela noticia, vamos somente tirar o .html dos links e deixar como estar (Vamos fazer isso tanto do arquivo noticias.ejs quanto do arquivo home.ejs).

//Por fim eu atualizei o arquivo noticia.ejs para que ele fique e se comporte da mesma forma como os arquivos anteriores, nesse caso assim que a gente acessa localhost:3000/noticia ele pega uma noticia especifica, mas fica tranquilo nas proximas aulas vamos arrumar uma forma de passar o id da noticia tanto no home.ejs quanto no noticias.ejs, e no noticia.ejs vamos recuperar esse id, puxar no banco de dados a noticia referente a esse id e mostrar essa noticia na tela =)

var app = require('./config/server');

app.listen(3000, function(){
    console.log("Servidor ON");
});
