//Esta é o nosso modulo da rota home, como falamos no arquivo app.js criamos isso aqui para ajudar a estruturar o nosso codigos da melhor forma (Futuramente voce vai me agradecer por estar fazendo isso).


module.exports = function(app){//O comando modele.exports ja sabemos para que serve, ele serve para retornar os codigos que estamos escrevendo abaixo. A unica alteração aqui é a existente do parametro 'app' dentro de function, mas pra que esse parametro serve ?

/*

Voce se lembra que no arquivo app.js a gente primeiro pegou as configurações do servidor e colocou dentro de uma variavel chamada app ? Dessa forma:

var app = require('./config/server');

Perfeito, e nas aulas seguintes a gente só precisou escrever este comando abaixo para reconhecer que determinado usuario digitou na url:

app.get('/', function(req,res){
    res.render('home/index');
});

Lá atras eu expliquei que para fazer esse tipo de coisa, primeiro devemos instanciar a classse do express em uma variavel e em seguida pegar essa variavel e usar o comando get para reconhecer as URLS aonde o nosso usuarios está indo ?

Perfeito! Como estruturamos o nosso codigo dessa forma, a variavel app não existe.... :(

Sendo assim, a unica alterantiva, seria:

1- No app.js deveriamos instanciar a classe do express (Isso ja estamos fazendo com a variavel app)

2- Como os comandos que fazem o reconhecimento das rotas está em um arquivo separado, devemos arrumar um jeito de passar a instancia dessa classe (do express) para dentro deste nosso arquivo home.js

3- A unica forma de fazer isso é passando a instancia por parametro (Como estamos fazendo)

Por isso que existe uma variavel 'app' ali dentro de function, porque assim que o app.js chamar esse modulo, alem dele chama-lo ele vai informar dessa a instancia, com isso a gente vai pegar essa instancia e vai continuar fazendo o nosso trabalho normalmente, ou seja, usando o app.get.... como estamos fazendo no comando abaixo:

*/


    //Bem, eu acho que os comandos abaixo voce reconhece e sabe muito bem para o que eles funcionam

    app.get('/', function(req,res){
        res.render('home/index');
    });
}

//Bem agora já podemos voltar ao arquivo app.js =)
