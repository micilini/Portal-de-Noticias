//Nesta aula vamos organizar ainda mais o nosso codigo e criar as rotas (que seriam os locais aonde os usuarios vão quando digitam /tecnologia ou /algumacoisa na URL).

var app = require('./config/server');

//Como vamos criar novas rotas e organizar ainda mais o nosso codigo, vamos ter que modificar algumas coisas! Como estamos vendo abaixo, a estrutura mudou um pouco e voce pode se perguntar, ue cade o app.get e o app.render ? Aonde eles foram ?

//Eles foram para arquivos separados! Mas por que ? Isso vai ajudar a gente na manutenção do nosso codigo futuramente e com isso a gente segue um modelo de programação que é muito usado nos dias atuais (MVC e responsabilidade unica).

//Nesse caso, os comandos responsaveis por reconhecer que determinado usuario quer acessar tal categoria do website, foram colocados dentro de arquivos na pasta app > routes. Essa pasta deve armazenar todos os arquivos e rotas. Então se a gente desejar criar uma nova rota para o nosso aplicativo, devemos criar um novo arquivo lá.

//Então antes de mais nada vamos pegar como exemplo a nossa primeira rota (que esta dentro de um modulo), para isso vá em app > routes > home.js

//Se voce foi no arquivo home.js podemos continuar com as explicações neste arquivo.

var rotaHome = require('./app/routes/home')(app);//Como vimos, a gente precisa instanciar o modulo de home e tambem passar por parametro a instancia do modulo de configuração do servidor aonde tem o express, e fazemos isso instanciando a função do modulo como vimos em outras aulas usando o ()... a unica diferença é que essa função pode receber um parametro, posso enviar um texto ou qualquer outra coisa, mas como ela requer uma instancia do express a gente passa a variavel app que declaramos logo acima.

var rotaNoticias = require('./app/routes/noticias')(app);//Este comando segue a mesma logica do comando acima!

var rotaFormInclusaoNoticia = require('./app/routes/form_inclusao_noticia')(app);//Este comando segue a mesma logica do comando acima!

//Não se esqueca de digitar no require o comainho completo utilizando './app/routes/' + o nome do arquivo que armazena a rota.

app.listen(3000, function(){
    console.log("Servidor ON");
});

//Pronto, podemos testar o nosso codigo agora e veremos que ele estará funcionando normalmente!
