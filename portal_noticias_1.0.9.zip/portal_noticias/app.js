//Nesta aula a gente vai aprender a como a gente pode passar aqueles dados que retornamos do MYSQL para dentro da nossa view para que o HTML possa trata-los e mostra-los organizadamente dentro de uma tabela. Bem não temos nada pra fazer neste arquivo então bora voltar pro aquivo noticias.js!

var app = require('./config/server');

var rotaHome = require('./app/routes/home')(app);

var rotaNoticias = require('./app/routes/noticias')(app);

var rotaFormInclusaoNoticia = require('./app/routes/form_inclusao_noticia')(app);

app.listen(3000, function(){
    console.log("Servidor ON");
});
