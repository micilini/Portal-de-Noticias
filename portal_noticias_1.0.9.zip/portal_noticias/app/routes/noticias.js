module.exports = function(app){
    app.get('/noticias', function(req,res){

        var mysql = require('mysql');

        var connection = mysql.createConnection({
            host: 'localhost',
            user: 'root',
            password : '1234',
            database : 'portal_noticias'
        });

        connection.query('select * from noticias', function(error, result){

        //Para que possamos passar o valor result sem ser pelo send (como estamos fazendo na outra aula), nos podemos usar o render com um parametro extra, observe:

        res.render("noticias/noticias", {noticia : result});//Aqui estamos passando um segundo parametro em formato de array, somente para ter uma chave e um valor, aqui funciona como se fosse uma variavel que estamos passando lá pro HTML aonde noticia seria o nome dessa variavel e o result (que armazena o JSON) o valor dos resultados retornados pelo nosso amigo MYSQL.

        //Bem agora para finalizar basta a gente dar uma olhada no arquivo da view da noticia, chamado noticia.ejs

        //Observe que o .EJS consegue tratar esses parametros que foram enviados, em um html normal isso nao seria possivel. Isso só é possivel via EJS porque tem um sistemaminha que roda por tras ;)

        });

    });
}
