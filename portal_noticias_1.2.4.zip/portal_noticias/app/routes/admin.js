module.exports = function(app){
    app.get('/formulario_inclusao_noticia', function(req,res){

        //Seja bem vindo de volta navegante, se voce chegou até aqui é porque chegou atraves do socia desta arquivo existente dentro da pasta controllers, então vamos lá.. basicamente e reforçando novamente a ideia o intuito deste arquivo é somente armazenar as rotas, a logica fica no nosso outro arquivo dentro da pasta controllers, OK!? Sim isso foi uma pergunta afirmação!

        //Sendo assim não podemos mais ter esse comando aqui de baixo:
        //res.render('admin/form_add_noticia', {'validacao' : {}, 'noticia' : {}});//Sim eu desativei ele, isso pra voce pegar a ideia, step by step!

        //Sendo assim o que precisamos fazer ? Precisamos chamar aquele arquivo do controller e enviar todos os parametros pra lá, como ? Da mesma forma que fizemos quando usamos o models lembra ?

        //Assim olha:
        app.app.controllers.admin.formulario_inclusao_noticia(app, req, res);//E foi isso que fizemos, chamamos lá dentro de controllers o nosso modulo de demos o nome de formulario_inclusao_noticia e enviamos os parametros e quando fizermos isso ele vai chamar a função e PIMBA! vai puxar o render e vai ficar tudo numa boa!

        //Quer ver se vai ficar tudo numa boa, roda teu servidor, entra no prompt, certifique-se de que esta na pasta dá aquele NODEMON MAROTO e acessa essa URL aqui: http://localhost:3000/formulario_inclusao_noticia

        //Ai voce pode pensar... po rapaz.. tava tão simples, geramos mais codigo pra fazer uma coisa simples! Eu te digo, muita calma nessa hora e voce não sabe o que diz! Aqui pode parecer besteira, mas o proximo comando abaixo 'app.post('/noticias/salvar'' É ENORME!

        //E nele sim vai valer a pena separar a logica do controller, mas isso nao quer dizer que em codigos bem simples como esse voce não precisará separar... HEIM!!!! TO DE OLHO!

        //Agora vamos analisar o app.post abaixo, tiramos toda logica e jogamos para dentro do nosso outro modulo!

    });


    app.post('/noticias/salvar', function(req,res){
       app.app.controllers.admin.formulario_salvar(app, req, res);//Same as the other! Ou se voce não entende nadinha de ingles, mesma coisa do outro! Só chamamos o modulo diferente offcourse (é claro rs).
    });

    //E é isso, nosso modulo de rotas trabalham somente com rotas, e os controllers ficam responsaveis por armazenar a parte da logica, mas se voce pensa que acabou em verdade eu te digo... ai não acabou falta fazermos e criamos controllers para todas as rotas restantes como home.js e noticias.js

    //Mas isso eu ja fiz e se voce dar uma olhada nos arquivos, você nao tera dificuldades para entende-los =)

    //Voce pode achar estranho se deparar com uma nova variavel chamada application enquanto que em aulas antigas ela simplesmente se chamava app, eu fiz isso porque ficar chamando app.app é meio que estranho e fica um pouco reduntande, então trocando app para application (Sim eu deveria ter feito isso tbm nesta aula) fica mais fácil entender porque estamos chamando application.app.seilaoque...

}
