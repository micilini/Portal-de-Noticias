module.exports.formulario_inclusao_noticia = function(app, req, res){//Aqui a gente criou um modo de exportação que leva o nome de formulario_inclusão_noticia que como dito vai armazenar todo o codigo responsavel por mostrar aquela tela do formulario pra gente! Se a gente ver, dentro dessa função estamos pegando 3 parametros, um tal de app que no caso seria o aplication que vem lá do server, o req que é a requisição vinda da rota existente dentro de admin.js e o res que é a resposta da rota vinda do admin.js.

  //Sendo assim, o que a gente fez... se a gente for no antigo arquivo admin.js existente na nossa ultima aula a rota estava mais ou menos assim:

  /*

  app.get('/formulario_inclusao_noticia', function(req,res){
      res.render('admin/form_add_noticia', {'validacao' : {}, 'noticia' : {}});
  });

  Como agora queremos separar as rotas da logica, o que teremos que fazer ?

  Bem a primeira coisa que foi criar os controllers nos ja fizemos, a segunda coisa que foi criar um modulo para armazenar esta logica nós tambem ja fizemos (que é o 'module.exports.formulario_inclusao_noticia = function(app, req, res){...'), agora basta a gente fazer o que ?

  Basta a gente copiar a logica existente dentro do comando da rota e trazer pra cá!

  Sabe identificar aonde a logica se encontra ?

  Tempo... valendo... tic toc... tic toc...

  É esse comando inteiro:

  app.get('/formulario_inclusao_noticia', function(req,res){
      res.render('admin/form_add_noticia', {'validacao' : {}, 'noticia' : {}});
  });

  Nãããããão!

  É esse comando aqui olha:

  res.render('admin/form_add_noticia', {'validacao' : {}, 'noticia' : {}});

  Porque se a gente ver dentro do nosso module.exports atual a gente já pega o app, o req e o res.

  Então basta a gente pegar esses codigos e lançar eles aqui dentro do nosso module exports!

  */

  res.render('admin/form_add_noticia', {'validacao' : {}, 'noticia' : {}});//Observe que o comando render faz parte do response que estamos recebendo por parametro do nosso module exports!

  //Feito isso, eu quero que agora voce abra o arquivo admin.js existente dentro da pasta routes, porque vai rolar modificações lá meu amigo!


}


module.exports.formulario_salvar = function(app, req, res){//Esse arqui segue a mesmissima logica do comando acima, se voce entendeu o comando acima não vai ter absoolutamente nenhuma dificuldade para etender esse codigozinho aqui!

  //Ta vendo esse codigo aqui em baixo ? Ele foi tirado lá do admin.js assim como fizemos com a logica do outro module acima! Fácil de entender não ? Até porque foi só um control + C seguido de um control + V =)

  var noticia = req.body;

  req.assert('titulo', 'Titulo é obrigatorio').notEmpty();
  req.assert('resumo', 'Resumo é obrigatorio').notEmpty();
  req.assert('titulo', 'Resumo deve conter entre 10 e 100 caracteres').len(10, 100);
  req.assert('autor', 'Autor é obrigatorio').notEmpty();
  req.assert('data_noticia', 'Data é obrigatorio').notEmpty().isDate({format: 'YYYY-MM-DD'});
  req.assert('noticia', 'Noticia é obrigatorio').notEmpty();

  var erros = req.validationErrors();

  if(erros){
   res.render('admin/form_add_noticia', {'validacao' : erros, 'noticia' : noticia});
   return;
  }


  var connection = app.config.dbConnection();
  var noticiasModel = new app.app.models.NoticiasDAO(connection);

  noticiasModel.salvarNoticia(noticia, function(error, result){
  res.redirect("/noticias");
  });

}
