//E agora sim meu PARCEIRO OU MINHA PARCEIRA! Vamos implementar os nossos controllers!

//Presta atenção porque esta aula é beeeeem extensa e o conteudo é bem fortezinho, mas nada que comigo voce nao possa entender rsrs

//A primeira coisa que devemos fazer é... é não! Eu vou perguntar pra vocês! No models e no views a gente teve que fazer algumas alterações.. quais foram elas ?

//Tic toc... tic toc... o tempo esta passando, ja sabe a resposta ?

//Enfim, não vou tomar muito do seu preciozinho tempo! A resposta principal é:

/*

Precisamos primeiro criar uma pasta chamada controllers dentro de app.
Segundo precisamos ir lá no server e adicionar essa nossa pasta controllers no consign (No comando then)

Fez isso ? Porque eu ja acabei de fazer!

Feito isso já podemos criar o nosso primeiro controller, então como dito nessa aula e nas aulas passadas vamos separar as rotas das logicas, então vamos abrir a pasta routes e pegar o primeiro arquivo chamado admin.js (Abre ele mas continua aqui nesta tela), vou começar com ele porque ele é o primeiro da fila alem de ser um dos arquivo mais densos e que tem mais codigos!

Vamos criar um controller pra ele ok ? Para isso crie um novo arquivo chamado admin.js dentro da pasta controllers que acabamos de criar acima... Se a gente for na aula passada e abrir o arquivo admin.js existente na pasta route iriamos ver que dentro do module exports ele tem 2 comandos principais:

* Um responsavel pela rota de inclusão de noticias ('formulario_inclusao_noticia')
* O outro é responsavel pela rota de salvar a noticia ('/noticias/salvar')

Sabe esses 2 comandos principais ? Então... eles vão virar controllers... SIIIIM

Para isso o que eu fiz... Eu fui lá no admin.js (EXISTENTE DENTRO DA PASTA CONTROLLERS) e criei 2 modulos de exportação um com o nome de formulario_inclusao_noticia e o outro com o nome de noticia_salvar.

Enfim, quero que agora voce começe a seguir esta aula pelo arquivo admin.js (EXISTENTE DENTRO DA PASTA CONTROLLERS) te vejo por lá!

*/

var app = require('./config/server');

app.listen(3000, function(){
    console.log("Servidor ON");
});
