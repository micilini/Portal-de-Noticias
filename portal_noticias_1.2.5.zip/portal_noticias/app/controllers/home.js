module.exports.index = function(appliction, req, res){
    res.render('home/index');
}