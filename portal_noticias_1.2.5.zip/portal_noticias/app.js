//Nesta aula a gente vai mapear os recursos estaticos da nossa aplicação que tambem conhecemos por assets, que nada mais é do que arquivos de imagens, arquivos javascript, arquivos de estilo (css), e depois desse mapeamento vamos começar a utilizar esses recursos no browser.

/*

Para isso eu criei varios arquivos de exemplo, então eu criei alguns html's, alguns arquivos e pastas chamada images, css e js.

Basicamente eu atualizei os nossos arquivos de views para esses novos arquivos que criei (O design está muito superior o das ultimas aulas, modestia a parte rs).

Então vamos lá para que isso seja possivel e esses assets possam ser instalados eu tive que criar dentro da pasta app uma nova pasta chamada public, essa pasta vai armazenar todos os arquivos que são publicos.

Publicos como assim ?

Por exemplo, quando voce acessa determinado website alem do html que voce vê, você ve estilos (arquivos css) você vê imagens e se voce inspecionar alguns elementos voce até vai ver alguns codigos javascript (Mas fica tranquilo que não são os codigos existentes dentro das pastas routes, models, controllers, config e node_modules relaxa kkk)

Lá dentro dessa pasta public eu carreguei algumas informações de assets como aquelas pastas de images, js e css.

Em seguida eu ajustei as nossas views, com o design maravilhoso!

Vamos começar pelo arquivo index.ejs que foi atualizado... quando eu joguei os arquivos lá e acessei a url 'localhost:3000' eu deixei de ver algumas imagens e algumas folhas de estilo, isso porque os caminhos não estavam conseguindo encontrar seus respectivos arquivos (js, css, e .png ou .jpg).

Para resolver esse tipo de problema eu tive que usar um recurso do NODEJS chamado STATIC, que na verdade é um middleware que vai identificar um diretorio com informações estaticas (que não se alteram, vulgo pasta public) e vai permitir que eles sejam acessados a partir da raiz da nossa aplicação!

Para configurar isso basta a gente ir em server.js e ver a modificação que fizemos lá.

A partir deste momento a gente consegue acessar tudo o que estiver dentro do public sem a necessidade de ir lá no html e informar o caminho dos arquivos inteiros como por exemplo:

Se esta assim: <link href="css/style.css" rel="stylesheet">

Deveria ficar assim: <link href="localhost:3000/app/public/css/style.css" rel="stylesheet">

Entendeu ? Não precisamos mais informar que determinado arquivo esta contigo dentro de app/public, o recurso static ja fez isso pra gente =)

Perfeito, na proxima aula vamos replicar toda a logica do back-end nessas novas views para que fique tudo certo novamente =)

Te encontra lá!

*/

var app = require('./config/server');

app.listen(3000, function(){
    console.log("Servidor ON");
});
