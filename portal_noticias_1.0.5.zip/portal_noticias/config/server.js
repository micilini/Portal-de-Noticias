//Este modulo é responsavel por armazenar as configurações do nosso servidor

var express = require('express');
var app = express();
app.set('view engine', 'ejs');

//E é claro, não podemos nos esquecer de exportar usando o commomJS, uma vez que devemos retornar a variavel app (que contem a instancia dos outros modulos) para o arquivo que esta chamando o config.js (que no caso é o app.js)

module.exports = app;
