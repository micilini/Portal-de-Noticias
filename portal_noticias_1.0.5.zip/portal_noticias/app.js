//Nesta aula a gente vai organizar um pouco os codigos, ou seja, vamos modularizar um pouco a nossa aplicação!

//Uma das coisas que a gente costuma separar é a configuração do servidor, ou seja:


/*

Esses codigos que estamos vendo abaixo:

var express = require('express');
var app = express();
app.set('view engine', 'ejs');

Eles costumam estar separados em um outro modulo (arquivo dentro do nosso projeto) aonde contem a configuração, ou seja, esse tipo de informação deve estar separado no modulo de configurações.

E foi exatamente isso que a gente fez neste projeto, se você verificar na pasta de arquivos nos criamos uma outra pagina chamada config e dentro dela um arquivo server.js aonde contem essas modificações.

Isso vai ajudar a gente mais pra frente quem sabe na manutenção do nosso codigo, alem de ficar mais organizado (assim como a gente vem fazendo com as views)

*/

//Agora nos precisamos chamar aquele nosso arquivo server.js com o require da seguinte forma:

var app = require('./config/server');//Não precisa colocar o .js como extensão

//Se rodarmos este codigo iremos ver que ele está funcionando bem, sendo assim quando precisamos fazer alguma outra configuração adicional no nosso servidor, vamos para o arquivo server.js em vez de vir pra cá (Falei que fica muito mais fácil rs)

app.get('/', function(req, res){
res.render('home/index');
});

app.get('/formulario_inclusao_noticia', function(req, res){
res.render('admin/form_add_noticias');
});

app.get('/noticias', function(req, res){
res.render('noticias/noticias');
});

app.listen(3000, function(){

   console.log("Servidor rodando com o express");

});
