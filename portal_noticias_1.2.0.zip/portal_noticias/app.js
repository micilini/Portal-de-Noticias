//Nesta aula a gente vai organizar o nosso codigo para que seja adicionado o express-validator. Então a primeira coisa que voce tem que ter em mente é que para que a gente veja na pratica como funciona o express validator e para que possamos usar aquelas funções vistas na aula anteior, vamos ter que aumentar um pouco a complexidade do nosso projeto, mas especificamente:

/*

Adicionar mais colunas no nosso banco de dados e mais campos na tela do nosso formulario, e é claro vamos ter que modificar os arquivos do nosso projeto para que ele consiga receber mais dados do nosso formulario para serem inputados dentro do nosso banco de dados!

Então vamos configurar o banco de dados, vou colocar aqui todo o processo que fiz, talvez te ajude...

1- Abra o PROMPT, e digite: cd C:\Program Files\MySQL\MySQL Server 5.7\bin

2- digite: mysql -u root -p

3- digite a senha que voce criou (a minha é 1234)

4- digite: use portal_noticias

5- digite: alter table noticias add column resumo varchar(100);

6- digite: alter table noticias add column autor varchar(30);

7- digite: alter table noticias add column data_noticia date;

Perfeito agora chegou a hora de implementar esses campos dentro do nosso formulario HTML!

Para isso vai em app > views > admin > form_add_noticia.ejs

Uma coisa bem legal é que se a gente perceber o nome dos formularios são o mesmo nome dos campos existentes no nosso banco de dados, e da maneira que estruturamos o nosso projeto no arquivo noticiasDAO.js ele ja faz uma inclusão desses campos automaticamente =)

Mas isso não basta, agora precisamos verificar se as informações que foram vindas daquele formulario são corentes, corentes como ?

Se obdecem o numero de caracteres, se realmente são do tipo date, se o campo não esta vazio... essas coisas, para isso vamos trabalhar agora no arquivo admin.js

*/

var app = require('./config/server');

app.listen(3000, function(){
    console.log("Servidor ON");
});
