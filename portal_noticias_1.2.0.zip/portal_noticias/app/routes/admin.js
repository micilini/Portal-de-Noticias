module.exports = function(app){
    app.get('/formulario_inclusao_noticia', function(req,res){
        res.render('admin/form_add_noticia', {'validacao' : {}});
    });


    app.post('/noticias/salvar', function(req,res){
        var noticia = req.body;

        //Agora que o express-validator ja esta como middleware da nossa aplicação basta utilizarmos ele para verificar se os campos realmente estão de acordo com o esperado (Sim, se voce for no formulario e deixar um dos campos em branco ele insere mesmo assim, tudo bem que poderiamos utilizar um comando do html5 nos formularios chamado 'require', mas mesmo assim é bom verificar tambem no back-end se os dados realmente estão vindo).

        //Para que isso seja possivel precisamos recuperar a variavel req que contem todas as requisições e utilizar um comando chamado assert, é com ele que iremos selecionar o campo e atribuir uma mensagem para esse campo por exemplo:

        /*

        req.assert('titulo', 'Este campo se chama titulo')

        Aqui estamos pegando o campo titulo que veio como parametro via metodo post e atribuindo a ele um determinado texto, mas esse comando em si não irá funcionar, pois ele precisa de outro comando de validação por exemplo: notEmpty() ou qualquer outro do tipo.

        Vejamos um exemplo abaixo:

        */

        req.assert('titulo', 'Titulo é obrigatorio').notEmpty();//Aqui estamos pegando a requisição e selecionando o campo titulo que veio do nosso formulario, até ai tudo bem, estamos atribuindo a ele uma descrição chamada 'Titulo é obrigatorio', mas essa descrição só será adicionada a ele caso... ai que vem o esquema... caso ele estiver vazio (Estamos verificando se ele esta vazio utilizando um dos comandos do express-validator chamado notEmpty()).

        //E é assim que funciona as validações do express-validator, podemos sim usa-los sem a necessidade de fazer um assert, somente selecionando cada campo, mas dessa forma fica mais fácil pra gente.

        req.assert('resumo', 'Resumo é obrigatorio').notEmpty();//Segue a mesma logica do comando acima.

        req.assert('titulo', 'Resumo deve conter entre 10 e 100 caracteres').len(10, 100);//Mesma logica, so que desta vez estamos verificando se o numero de caracteres do titulo esta entre 10 e 100, caso for menor que 10 ele atribui essa mensagem, caso for maior que 100 ele tambem atribui essa mensagem.

        req.assert('autor', 'Autor é obrigatorio').notEmpty();//Mesma logica do comando acima

        req.assert('data_noticia', 'Data é obrigatorio').notEmpty().isDate({format: 'YYYY-MM-DD'});//Mesma logica, no caso deste estamos fazendo duas verificações ao mesmo tempo, o primeiro é para saber se o campo que veio não esta vazio e caso nao estiver ele ainda verifica se a data veio no formato certo (Formato americano: ANO-MES-DIA) voce pode se perguntar que no formulario o forma como a data vem é no formato brasileiro (DIA-MES-ANO), pode até parecer mas de baixo dos panos o HTML5 sempre retorna a data no formato americano.

        req.assert('noticia', 'Noticia é obrigatorio').notEmpty();//Mesma logica do comando acima

        //Agora que ja criamos os nossos comandos que fazem a verificação de todos os campos, chegou a hora de fazer a PARTE 2, essa parte consiste em: 'Caso alguma validação encontrar algum erro, ou seja, um campo estiver vazio ou afins, vamos para a aexecução do codigo e não deixar ele ir pra dentro do banco de dados!'

        var erros = req.validationErrors();//Quando utilizamos o assert, automaticamente é criado uma nova propriedade dentro de req aonde armazena os erros, essa propriedade se chama validationErros() e contem todos os erros salvos em formato JSON.

        if(erros){//Aqui estamos verificando se a variavel erros é verdadeiro, se for verdadeiro isso significa que tem informações contidas dentro dessa variavel e se tem informações dentro dela isso significa que algum campo não passou na validação, sendo assim vamos trata-lo aqui:

          //Lembra que eu disse acima que: 'Caso um campo não passese na validação que não poderiamos deixar ele salvar no banco de dados ?'... então, esse return (no final do nosso if) para a execução de todo o codigo não deixando ele seguir em frente depois do IF

         //Bem, já que nao podemos deixar continuar, devemos mandar o usuario para a mesma tela, para isso podemos usar o comando render:

         //res.render('admin/form_add_noticia');// esse comando vai dar uma ideia de que algo deu errado e o registro ainda não foi salvo por conta de algum erro. Mas se a gente inserir assim na cara DURA, o usuario nao vai saber o que fazer, uma vez que nao estamos informando a ele de que todos os campos são obrigatorios e que devem seguir algumas regras.

         //Sendo assim precisamos retornar esses erros junto com o render e trata-los dentro do nosso formulario, para que quando vier a variavel chamada erros, ele mostre os erros na tela do usuario! Vejamos como isso funciona:

         //Como o retorno da variavel erros armazena um JSON, podemos aproveitar isso e passar diretamente para dentro da nossa view:

         res.render('admin/form_add_noticia', {'validacao' : erros});//Estamos passando os erros em formato json para a nossa view, feito isso podemos abrir o arquivo form_add_noticia.ejs para acompanharmos as modificações.

         //Se tentarmos acessar irá ser retornado pra gente um erro dizendo que a validação nao foi definida, para resolver isso vai no inicio desse projeto e informa o parametro validação lá (Observe que eu ja fiz aquilo).

          return;//Já expliquei pra que isso aqui serve rs


        }



        var connection = app.config.dbConnection();
        var noticiasModel = new app.app.models.NoticiasDAO(connection);

        noticiasModel.salvarNoticia(noticia, function(error, result){
        res.redirect("/noticias");
        });


    });

}
