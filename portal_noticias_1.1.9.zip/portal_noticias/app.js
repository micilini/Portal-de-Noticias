//Nesta aula a gente vai aprender a realizar algumas validações de dados usando o express-validator, em sumo esse modulo ele ja vem com funções pre determinadas capazes de validar se um dado é um inteiro, se um e-mail veio certo, se determinada variavel esta vazia ou não, exemplos de funções:

/*

notEmpty();
isAlpha();
isInt();
isEmail();
len(4,8);

Isso é feito atraves de um middleware, ou seja, as pessoas disparam dandos para o servidor atraves de requisições post (vimos isso na aula que configuramos o nosso formulario) e o express-validator incluido como middleware da nossa aplicação vai tratar o objeto request.

E este tipo de coisa vai agilizar muito o nosso trabalho, alem das funções quando um determinado criterio não é atendido, ele retorna um erro pra gente! Então podemos testar essa variavel e verificar se ela é verdadeira ou falsa. Se for falsa a gente segue o fluxo da aplicação, se der verdadeiro tratamos esse erro e retornamos uma mensagem para o usuario que tentou fazer o request.

*/

//Chegou a hora de instalar o express-validator na nossa aplicação, primeiro certifique-se de que o prompt esta aberto e voce esta dentro da pasta do seu projeto, feito isso basta executar o seguinte comando 'npm install express-validator --save'.

//Após feito a instalação e como ele é considerado um middeware nos precisamos incluir ele na inicialização da nossa aplicação, para isso vamos até o arquivo server.js

var app = require('./config/server');

app.listen(3000, function(){
    console.log("Servidor ON");
});
