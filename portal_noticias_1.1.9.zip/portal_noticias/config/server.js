var express = require('express');
var consign = require('consign');
var bodyParser = require('body-parser');
var expressValidator = require('express-validator');//Precisamos dar um require do modulo do express validator para que possamos usa-lo na nossa aplicação.

var app = express();
app.set('view engine', 'ejs');
app.set('views', './app/views');

app.use(bodyParser.urlencoded({extended : true}));
app.use(expressValidator());//Estamos adicionando o express-validator para dentro da nossa aplicação utilizando o app.use

consign()
      .include('app/routes')
      .then('config/dbConnection.js')
      .then('app/models')
      .into(app);

module.exports = app;
