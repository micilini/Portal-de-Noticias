module.exports = function(app){

    app.get('/noticias', function(req,res){

        var connection = app.config.dbConnection();
        var noticiasModel = new app.app.models.NoticiasDAO(connection);

        noticiasModel.getNoticias(function(error, result){
        res.render("noticias/noticias", {noticia : result});
        });


    });

    //Como falamos, peguei a rota e coloquei aqui dentro uma vez que estava muito redundante manter noticia.js!

    app.get('/noticia', function(req,res){

        var connection = app.config.dbConnection();
        var noticiasModel = new app.app.models.NoticiasDAO(connection);

        noticiasModel.getNoticia(function(error, result){
        res.render("noticias/noticia", {noticia : result});
        });

    });

}
