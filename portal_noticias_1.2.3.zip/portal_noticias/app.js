//Nesta aula iremos dar mais um passo na arquitetura da nossa aplicação, como falamos na aula anterior chegou a hora de transformar, digo não transformar mais pegar alguns codigos existentes dentro do nosso arquivo de rotas e coloca-los separados em um controller!

//Se a gente for dentro do nosso arquivo chamado admin.js voce verá que ele estava fazendo um papel de controller, pois alem dele implementar as rotas ele esta implementando alguns codigos que fazem salvamentos no banco de dados e afins, e esses codigos devem estar localizados dentro de controllers!

//Então é interessante que essas rotas de negocio estejam separadas das logicas por isso nesta aula vamos separar as rotas das logicas atraves de que gente ?

//CONTROLLERS!

//Então a primeira coisa que iremos fazer antes de falar sobre controllers é ajustar pelo menos 2 rotas que temos! Pois ambas pelo que vi estão redundantes! Vamos transformar noticia.js e noticias.js em um unico arquivo chamado noticia.js. uma vez que ambas apontam para dentro do diretorio de views > noticias!

//Para isso eu fiz o seguinte eu abri o arquivo chamado noticia.js e copiei todo o conteudo existente dentro de module.exports e colei dentro do arquivo noticias.js mais especificamente dentro do module.exports de lá!

//E por fim basta a gente deletar o arquivo noticia.js das nossas routes, pois não precisaremos mais dele!

//Infelizmente não vai ser dessa vez que iremos implementar os nossos controllers uma vez que assim que implementarmos ele precisamos modificar tambem o arquivo noticias.js então pra nçao ficar muito complicado vou deixar isso para a proxima aula!

//Step by Step para que voce possa entender =)

var app = require('./config/server');

app.listen(3000, function(){
    console.log("Servidor ON");
});
