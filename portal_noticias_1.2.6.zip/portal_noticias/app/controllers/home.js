module.exports.index = function(application, req, res){

    //Como no home apartir de agora temos que pegar as noticias vindas do banco de dados e mostrar na tela inicial temos que fazer aquele processo de comunicação com o banco de dados, lembram dos codigos ? Bem se voce não lembra basta entrar no noticias.js e clocar os comandos de comunicação:

    var connection = application.config.dbConnection();
    var noticiasModel = new application.app.models.NoticiasDAO(connection);

    //Show, agora basta a gente chamar uma das funções responsaveis por pegar as 5 ultimas noticias e em seguida utilizar esse comando: res.render('home/index'); só que passando o parametro de resultado pra dentro do index.ejs (Assim como fizemos em noticias).

    //Só que para isso se a gente analisar o modulo de NoticiasDAO, não existe nenhuma função com nenhum codigo SQL que retorne para a gente as 5 ultimas noticias cadastradas no banco de dados, sendo assim o que faremos ? Criamos essa função e esse SQL oxi! (De uma olhada no noticiasDAO.js)

    noticiasModel.get5UltimasNoticias(function(error, result){//Este codigo não tem muitos misterio, só estamos retornando as 5 ultimas noticias do banco de dados e passando para a nossa index!
      console.log('Veja will: ' + result);
        res.render('home/index', { noticias : result });
    });

    //Pasra finalizar basta a gente processar esse parametro =) (Como fizemos!)

}
