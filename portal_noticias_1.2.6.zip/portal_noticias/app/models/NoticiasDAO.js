function NoticiasDAO(connection){
    this._connection = connection;
}

NoticiasDAO.prototype.getNoticias = function(callback){
    this._connection.query('SELECT * FROM noticias', callback);
}

NoticiasDAO.prototype.getNoticia = function(callback){
    this._connection.query('SELECT * FROM noticias WHERE id_noticia = 2', callback);
}

NoticiasDAO.prototype.salvarNoticia = function(noticia, callback){
    this._connection.query('INSERT INTO noticias SET ?', noticia, callback);
}

NoticiasDAO.prototype.get5UltimasNoticias = function(callback){//Criamos uma nova função sem muitos misterios chamada get5UltimasNoticias aonde vai retornar do banco de dados as 5 ultimas noticias inseridas
    this._connection.query('SELECT * FROM noticias ORDER BY data_criacao DESC LIMIT 5', callback);//Esse é aquele comando que pega as 5 ultimas noticias do banco de dados, bem simples de entender, só resta voce entender o SQL, mas ele diz assim mais ou menos "Seleciona todos os campos da tabela noticia, traga esses resultados ordenados pela data_criacao no formato decrescente (ou seja os ultimos inseridos), sendo que so quero que voce me retorne 5 resultados"
}

module.exports = function(){
    return NoticiasDAO;
}
