//Agora que as nossas views já foram atualizadas devemos colocar a home.ejs para funcionar, se voce percebeu na ultima aula assim que a gente acessa 'localhost:3000' nos deparamos com uma tela aonde contem algumas noticias listadas, noticias de mentirinha né.. é obvio, porque se fosse de verdade estariamos pegando elas diretamente no banco de dados, e o intuito desta aula é este!

//Ou seja, nesta aula nos iremos colocar as noticias existentes no nosso banco de dados dentro da nossa home! Lá nos vamos listar as 5 ultimas noticias cadastradas tendo como base a criação de cada uma delas!

//Enfim, nesta aula iremos trabalhar com 2 arquivos: index.ejs (A view) e home.js (O Controller), te aguardo no home.js

var app = require('./config/server');

app.listen(3000, function(){
    console.log("Servidor ON");
});
