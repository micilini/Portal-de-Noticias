module.exports = function(app){
    app.get('/formulario_inclusao_noticia', function(req,res){
        res.render('admin/form_add_noticia');
    });


    app.post('/noticias/salvar', function(req,res){
        var noticia = req.body;
        //res.send(noticia);

        //Para que funcione aquilo que queremos fazer precisamos pegar a conexão com o banco de dados, chamar o model de noticias e fazer todo aquele esquema, só que em vez de selecionar (como estavamos fazendo anteriormente), nós vamos inserir novos dados:

        var connection = app.config.dbConnection();//Já sabemos como esse codigo funciona
        var noticiasModel = app.app.models.noticiasModels;//Esse aqui tbm...

        noticiasModel.salvarNoticia(noticia, connection, function(error, result){//Aqui estamos chamando uma nova função que iremos criar lá dentro do nosso model chamado salvarNoticia e antes da conexão estamos enviando mais um parametro chamado noticia que no caso é a variavel que pega aqueles valores digitados no nosso formulario

        res.redirect("/noticias");//Aqui estamos usando um comando novo chamado redirect, esse comando na verdade ele redireciona o usuario para uma nova URL, nesse caso assim que a noticia for adicionada no banco de dados, o usuario deverá voltar para a tela aonde aparece a lista de todas as noticias, portanto estamos redirecionando ele para a tela de redirect (E de lá ele atualiza e puxa todas as noticias do banco de dados). Obs: Se fizermos o render aqui iriamos nos deparar com os seguintes problemas: 1- A noticia recem adicionada nao iria aparecer, 2- se o usuario atualizar a tela o borwser vai mandar uma mensagem de que 'voce deseja reenviar este formulario...' o que vai adicionar registros duplicados no banco de dados.
        });

        //Feito isso podemos ir para o arquivo chamado noticiasModels.js existente dentro de models

    });

}
