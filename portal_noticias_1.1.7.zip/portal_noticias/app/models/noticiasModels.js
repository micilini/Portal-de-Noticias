module.exports = function(){


  this.getNoticias = function(connection, callback){
      connection.query('select * from noticias', callback);
  }

  this.getNoticia = function(connection, callback){
      connection.query('select * from noticias where id_noticias = 1', callback);
  }

  //Chegou a hora de implementar aquela função que vai salvar a noticia (que declaramos no arquivo anterior)

  this.salvarNoticia = function(noticia, connection, callback){
      connection.query('insert into noticias set ?', noticia, callback);//Aqui existe aquilo que eu chamo de PULO DO GATO:

      /*

      Sabemos como funciona o comando do insert into não sabemos ? Bem se voce ainda nao sabe recomendo que faça um curso e entenda um pouco de SQL, mas aqui estamos fazendo algo diferente da maneira convencional, eu acho que quando voce abriu esse arquivo voce esperou encontrar algo como:

      insert into noticias (titulo, noticia) values ...

      Mas não... fizemos uma coisa mais rapida, usando o comando set do banco de dados, na verdade o banco de dados do node (o driver) ele ja consegue processar determinadas requisições de modo que podemos inserir somente o nosso json aonde contem os dados.

      Masssss um detalhe muito importante! É necessario que as chaves desse JSON sejam as mesmas do banco de dados, por exemplo: Lá no formulario nós criamos um campo e demos a ele o name de titulo e o outro de noticia.

      Quando a gente recupera esses dados com o req.body ele vem mais ou menos assim:

      {'titulo' : 'meu titulo', 'noticia' : 'minha noticia'}

      Vemos ali que temos o nome do campo e em seguida o valor armazenado desse campo, correto ?

      Bem, sabemos que no banco de dados chamado noticias nos criamos alguns campos chamados: id_noticias, titulo, noticia, date...

      Podemos ver ali que no JSON e no banco de dados existe um campo que se chama titulo e um outro que se chama noticia, nesse caso se fizermos o insert utilizando o set o driver nao encontrará problemas de inserir no banco de dados o titulo e a noticia... mas se por ventura voce for lá no codigo html e alterar os nomes VAI DAR ERRO.

      Então resumindo: É fundamental que o JSON possua o rotulo das variaveis o mesmo nome que as colunas da tabela.

      */
  }

  return this;

}
