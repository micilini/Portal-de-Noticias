//Agora chegou o momento de fazer com que aqueles dados que estão sendo enviados pelo nosso formulario caia dentro do nosso banco de dados para que assim a gente possa adicionar novas noticias pelo nageador, ou será que voce prefere ficar adicionando noticias pelo promot ?

//Veja agora o arquivo admin.js

var app = require('./config/server');

app.listen(3000, function(){
    console.log("Servidor ON");
});
