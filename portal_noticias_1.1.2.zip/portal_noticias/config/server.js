//Vai ser neste arquivo que tem as configurações do servidor que o consign vai ser instalado e aplicado.

var express = require('express');
var consign = require('consign');//A primeira coisa que devemos fazer e que todos nos sabemos é que para usar um modulo nós devemos... (Sim, dar um require nele rs)

var app = express();
app.set('view engine', 'ejs');
app.set('views', './app/views');

//O consign deve ser atribuido a variavel app que declaramos acima (na instancia do modulo do express), mas porque devemos declarar o consign ali dentro ? Porque o express é o servidor em si, e é ele que esta sendo exportado pelo module.exports, não podemos exportar simplesmente o cosgin pois ele é um modulo a par, uma vez que no app.js estamos utilizando uma instancia da variavel app (o metodo listen) para criar o nosso servidor, e não... não é possivel usar o metodo listen com o cosign e por isso que o cosign deve ser atribuido junto ao modulo do servidor que no nosso caso é o express.

//Então continuando:

consign().include('app/routes').into(app);//Aqui funciona da seguinte forma:

/*

consign() aqui estamos chamando a função do consign para instanciar a classe que iremos utilizar!

include(), já expliquei pra voce anteriormente que com o consign ele vai carregar as nossas rotas automaticamente sem a necessidade de usar um require como estavamos fazendo no app.js certo ? Sim, mas para que isso funcione devemos informar ao cosign aonde estão os arquivos que irão ser carregados automaticamente, voce consegue se lembrar aonde estão os arquivos que contem as rotas ? Eles estão dentro de app > routes

E é claro devemos informar ao cosign aonde estes arquivos estão (Não o cosign não é tão inteligente assim não rs)

Então é no include que iremos informar o local como estamos fazendo (app/routes) usamos app porque esse arquivo server.js na vdd esta sendo carregado dentro do app.js que esta no diretorio principal da aplicação.

into() é o local aonde a instancia do consign vai junto, geralmente é pro modulo capaz de rodar o servidor, ou é o http (mas não estamos mais utilizando ele) ou é pro express (que estamos utilizando no momento).

*/

//E pronto, o seu projeto esta funcionando como antes!

module.exports = app;
