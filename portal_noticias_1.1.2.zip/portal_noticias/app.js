//Nesta aula vamos aprender a instalar o modulo dentro da nossa aplicação chamada cosign, mas antes devemos entender como ele é funciona.

/*

Explicando de uma maneira simplista, o cosign ele é um modulo que consegue automaticamente carregar outros modulos (outros arquivos) existentes dentro de nossa aplicação sem ter que fazer require em cada um deles, exemplo:

Abaixo no antigo app.js estavamos fazendo o seguinte para implementar as nossas rotas:

var app = require('./config/server');

var rotaHome = require('./app/routes/home')(app);

var rotaNoticias = require('./app/routes/noticias')(app);

var rotaFormInclusaoNoticia = require('./app/routes/form_inclusao_noticia')(app);

Ou seja, estavamos carregando elas UMA POR UMA dentro da nossa aplicação!

Com o cosgin basta chamarmos o modulo e pronto, ele faz o autoload dos nossos outros modulos.

*/

//Gostou do que viu ? Isso vai economizar tempo pra caramba na nossa aplicação não acha ? Então vamos instalar o cosign ?

//Vamos!

//Lembre-se de estar dentro da pasta aonde se encontra o seu projeto e digite assim no prompt 'npm install consign --save'.

//E pronto, para verificar se o cosgin esta instalado basta abrir a pasta node_modules e voce verá que ele esta instalado com sucesso!

var app = require('./config/server');

//Agora que temos o consign instalado dentro do nosso projeto, não precisamos mais ficar dando esss require para dentro desse arquivo (Imagina a gente com um projeto com mais de 40 rotas e a cada nova rota criada a gente entrar dentro desse arquivo e ficar fazendo require ? Imagina o quão grande esse arquivo seria... imagina voce dando manutenção nele :o)


//var rotaHome = require('./app/routes/home')(app);

//var rotaNoticias = require('./app/routes/noticias')(app);

//var rotaFormInclusaoNoticia = require('./app/routes/form_inclusao_noticia')(app);

//Sabe porque as rotas acima estão comentadas ? Porque elas não serão mais usadas dessa forma, agora o cosign esta sendo usado e aplicado dentro da variavel app que tem a instancia do server.js, então meu amigo... vamos abrir esse arquivo agora e entender como o cosign funciona ;)

app.listen(3000, function(){
    console.log("Servidor ON");
});
