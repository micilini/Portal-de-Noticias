//Nesta aula a gente vai fazer uma introdução a nossa estrutura que a gente esta utilizando que é o MVC, cujo significado é model view controller, relaxa que não precisamos sair desta tela, basta voce ler o que estou falando aqui e na proxima aula a gente vai reestruturar os nossos arquivos e encaixar os controllers dentro do nosso projeto (Visto que ja temos os models e as views).

/*

O padrão MVC é muito utilizado profissionalmente por ser um design pattern bem fácil de se trabalhar e bem estruturado alem de ajudar na manutenção do nosso codigo.

O padrão MVC nos permite separar as logicas de entrada, logicas de negocio, e logicas de interface de do usuario em locais bem especificos dentro do nosso aplicativo. O padrão MVC sugere 3 separações:

Os models são os dados da nossa aplicação, são centralizadas as regras de negocio, no portal de noticias usamos ele para manipular a gente tabela de noticias do nosso banco de dados.

As views servem para fornecer um tipo de representação de dados, de interface, no nosso portal de noticias usamos as views para armazenar nosso arquivos de html estaticos em conjunto com o EJS.

Já o controller ele é um mediador, ele recebe as requisições dos clientes, que podem ser usuarios ou outros aplicativos e converte essas requisições em comandos que vão atuar sobre os nossos models e views.

No nosso projeto pratico implementaremos os controllers junto com as rotas do nosso sistema de tal modo a oferecer para cada rota um tipo de controller especifico.

Os objetivos principais do MVC consiste em:

* Reutilização de codigo
* Separação de conceitos
* Estrutura mais contida para trabalho em equipe

Entendendo o padrão MVC vai fazer voce entender o funcionamento de diversos outros frameworks tambem de outras linguagens de pogramação!

Bem ja falei demais, agora chegou a hora de fechar o nosso MVC, então na proxima aula iremos aprender a tirar todo aquele codigo das rotas e separa para cada rota um determinado controller!

*/

var app = require('./config/server');

app.listen(3000, function(){
    console.log("Servidor ON");
});
