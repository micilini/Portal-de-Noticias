//Nesta aula vamos continuar organizando os nossos modulos com o cosign, só que agora quem vamos organizar vai ser o arquivo dbConnection.js existente dentro de config.

//Devemos prestar bastante atenção nessa aula, cada detalhe que será explicado aqui faz sentido quando se tratamos de design pattern.

/*

E qual a real vantagem de colocar a conexão com o banco de dados dentro de consign ?

Se a gente for lá dentro de noticias.js veremos esse pedaço de codigo:

var dbConnection =  require('../../config/dbConnection');

Imagina que tenhamos 40 rotas no nosso projeto e 39 delas precisam fazer uma conexão com o banco de dados, isso diz que em cada pagina nos deveremos fazer um require do nosso modulo do banco de dados, e como voce deve ter notado, cada vez mais estamos modulando a nossa aplicação, estamos indo ai pra um nivel bem organizado para que no futuro possamos desenvolver aplicações em time.

Mas não só isso, fazemos isso tambem para dar uma cara mais profissional para a nossa aplicação.

Pois bem, vamos agora para dentro do nosso arquivo dbConnection.js !


*/

var app = require('./config/server');

app.listen(3000, function(){
    console.log("Servidor ON");
});
