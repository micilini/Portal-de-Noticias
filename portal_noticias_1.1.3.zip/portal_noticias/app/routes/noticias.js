//A porposta agora é retirar esse require do banco de dados e usa-lo dentro do nosso consign, sendo assim a primeira coisa que devemos fazer é comentar essa linha de baixo (Pois não iremos mais utiliza-la):

//var dbConnection =  require('../../config/dbConnection');

//Antes de prosseguir, vamos agora para o arquivo server.js

//Bem se voce fez todo o percurso, chegou em dbConnection.js e voltou, voce ja deve estar entendendo como funciona os esquemas kkk

module.exports = function(app){

  //Agora que sabemos que dentro de app contem uma instancia da classe de dbConnection e ela esta dentro de uma variavel podemos fazer igual nos fazemos no php (se voce entende essa linguagem é claro) chamado namespaces, observe:

   //var connection = dbConnection(); Cortamos de cena esse codigo, a variavel nem existe mais!

    app.get('/noticias', function(req,res){

        var connection = app.config.dbConnection();//Como o dbConnection agora esta dentro de app (feito pelo consign) podemos pegar a instancia utilizando esse comando acima e instanciando a classe de comunicação com o banco de dados!

        connection.query('select * from noticias', function(error, result){

        res.render("noticias/noticias", {noticia : result});

        });

    });
}

//E pronto, agora a conexão com o banco de dados só será estabelecida não quando entrarmos em 'localhost:3000' ou 'localhost:3000/form_inclusoa_noticia', mas sim quando entrarmos em 'localhost:3000/noticias' pois ele é o unico arquivo que faz essa comunicação.
