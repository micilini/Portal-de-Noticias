var express = require('express');
var consign = require('consign');

var app = express();
app.set('view engine', 'ejs');
app.set('views', './app/views');

//Antes o nosso codigo estava assim: consign().include('app/routes').into(app); Agora como estamos vendo abaixo ele já mudou um pouco, vejamos:

consign()
      .include('app/routes')
      .then('config/dbConnection.js')
      .into(app);


/*

Vamos lá, quem é esse tal de then() que entrou ali ?

O then() do portugues para o ingles significa 'então', nesse caso estamos instanciando o consign e incluindo todas as nossas rotas e então (then) estamos incluindo o nosso banco de dados. No then podemos incluir outros modulos na nossa aplicação podem ser:

* diretorios
* controllers

Ou no nosso caso pode ser E VAI SER o config. So que se chegassemos e incluissemos dessa forma .then('config'), o consign quando faz o load dos nossos modulos, ele executa o que ele exportar.

Então se o modulo exporta uma função, ele ja executa essa função automaticamente. Então se deixarmos o config ali dentro e executar o servidor vai acontecer uma coisa bem estranha, o app.js vai rodar, o server,js vai rodar e nunca mais vai parar de rodar uma vez que é no server que as coisas acontecem e colocando 'config' dentro de then o programa vai entrar em um loop infinito isos porque a função que esta sendo exportada por esse arquivo roda automaticamente!

Então para corrigir isso colocamos then('config/dbConnection.js');, assim estamos fazendo a referencia de qual modulo especifico eu quero carregar dentro daquele diretorio. Nesse caso devemos colocar a extensão .js, porque se colocarmos somente dbConnection ele vai pensar que isso é um diretorio.

*/

//Perfeito este arquivo ja esta configurado, agora basta a gente ir no arquivo dbConnection.js que lá tem alteração!


module.exports = app;
