//Este arquivo foi alterado, vamos ver como ele era antigamente:

/*

var mysql = require('mysql');

module.exports = function (){

  return mysql.createConnection({
      host: 'localhost',
      user: 'root',
      password : '1234',
      database : 'portal_noticias'
  });


}

Como todos ja sabemos ele faz o require do mysql e em seguida ele exporta uma função que retorna a criação do banco de dados. Mas agora com o consign o jogo mudou. O banco de dados agora vai ser instanciado automaticamente quando a aplicação roda! Ou seja, a gente entra na home e a comunicação com o banco de dados é feita! Isso esta errado porque na home não estamos fazendo nenhuma conexão com o banco de dados, somente na area de noticias.

Então para corrigir este problema (que nem vem a ser um problema), isso na verdade posso comparar com uma ação desnecessaria no momento, sabe aquela sensação de "Isso não precisa ser feito", "sem motivo algum" então...

Sabendo que agora estamos usando consign e que como foi dito no modulo anterior "....se o modulo exporta uma função, ele ja executa essa função automaticamente...." como podemos resolver este problema ?

Podemos exportar uma variavel em vez de uma conexão propriamente dita! E dentro dessa variavel tem uma função e dentro da nossa aplicação a gente executa essa função quando acharmos melhor.

Observação: Chamar classes que não serão usadas no momentos, modulos, conexões só fazem comer mais memoria da maquina, então muito cuidado. (Tudo bem que é imperceptivel, dependendo da maquina é claro) mas é bom fazer as coisas bem feitas!

Então vamos colocar a mão na massa:


*/

var mysql = require('mysql');

//Abaixo criamos uma variavel aonde contem uma função que faz a conexão com o banco de dados

var connMySQL = function(){

  return mysql.createConnection({
      host: 'localhost',
      user: 'root',
      password : '1234',
      database : 'portal_noticias'
  });

}

module.exports = function (){

  return connMySQL;//E no modulo de exportar basta que enviarmos a variavel que armazena a função de conexão com nosso banco de dados. Isso impede que o banco de dados seja chamado pelo consign sem que seja necessario, uma vez que agora ela estará contida dentro de uma variavel

}

//Pronto, final da nossa viagem, podemos voltar agora para o arquivo noticias.js
