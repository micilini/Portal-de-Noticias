//Para voce poder entender o que eu fiz aqui, foi pegar aqueles codigos responsaveis por fazer a conexão com o banco de dados, estes aqui:


/*

var mysql = require('mysql');

var connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password : '1234',
    database : 'portal_noticias'
});

*/

//E joga-los para dentro de um arquivo chamado dbConnection.js que acabei de criar dentro da pasta config. Isso foi feito porque não tem muito haver a gente ter uma conexão com o banco de dados dentro de uma rota que é a rota de noticias, e mesmo assim se eu fosse fazer dessa maneira eu deveria fazer em outras rotas como home.js e form_inclusao_noticia.js (que precisam do banco de dados) e quem sabe outros arquivos futuros, então meu codigo iria se repetir varias e varias vezes... agora imagina que eu tenha alterado a senha do banco de dados... eu vou ter que alterar a linha password em todos os arquivos de rotas que fazem conexão com o banco de dados (OLHA QUE LOUCURA!!!).

//É bem mais inteligente criar um modulo separado, e dentro de uma das rotas que utilize o banco de dados chamar esse modulo e caso eu precise fazer alguma modificação no banco de dados só iria precisar alterar esse arquivo dbConnection.js que todos sofreriam alteração =P

//De uma olhada no arquivo dbConnection.js e volte aqui para mais explicações!

//Enfim, agora basta a gente chamar esse modulo do dbConnection.js para dentro da nossa aplicação da seguinte forma:

var dbConnection =  require('../../config/dbConnection');//Estamos utilizando o ../ para voltar uma pasta para que o sistema possa encontrar o arquivo dentro da pasta certa!


module.exports = function(app){

   //Em seguida basta instanciarmos a classe do dbConnection que acabamos de criar, e pegar a instancia da conexão com banco de dados:

   var connection = dbConnection();//Utilizamos a mesma variavel chamada connection, isso para nao alterar o nome dos codigos abaixo que utilizam essa variavel para pegar a conexão com o banco de dados, mas se voce alterar o nome dessa variavel vai ter que alterar o nome ali no comando query abaixo...

    app.get('/noticias', function(req,res){

        connection.query('select * from noticias', function(error, result){

        res.render("noticias/noticias", {noticia : result});

        });

    });
}

//E pronto, o arquivo estará rodando como na ultima aula!
