//Nesta aula ainda sobre banco de dados, vamos organizar a estrutura do nosso codigo de conexão com o banco de dados que esta largado lá dentro do arquivo noticias.js.

/*

Porque estamos estruturando o nosso codigo tãããão bem ?

Isso aqui não é só perfecsionismo, na verdade, separar essas estruturas permite que aplicações maiores sejam desenvolvidas em time, então voce vai ter uma galera responsavel por fazer o front end da sua aplicação, então eles vão trabalhar somente com os arquivos existente na pasta view. Voce vai ter uma galera responsavel por configurar o servidor ou a conexão com o banco de dados então nao vai ter problema uma vez que eles vão trabalhar somente com a pasta config. e Por fim uma outra galera trabalhando no back-end então eles só trabalham por aqui mesmo rs.

Agora imagina isso daquela forma que fizemos anteriormente de colocar o res.end('CODIGO HTML AQUI'), nao iria dar muito certo, porque isso iria cortar um pouco a produtividade... então  agalera do front end nao vai poder alterar nada enquanto a galera do back-end estiver criando codigos uma vez que nesse caso vai estar tudo dentro de um unico arquivo...

Então modularizar a nossa estruutra leva a gente para um design patter chamado MVC, que estamos construindo aos poucos.

*/

//Então vamos colocar a mão na massa e isolar o nosso metodo de conexão com o banco de dados! Nos encontramos no arquivo noticias.js ;)

var app = require('./config/server');

var rotaHome = require('./app/routes/home')(app);

var rotaNoticias = require('./app/routes/noticias')(app);

var rotaFormInclusaoNoticia = require('./app/routes/form_inclusao_noticia')(app);

app.listen(3000, function(){
    console.log("Servidor ON");
});
