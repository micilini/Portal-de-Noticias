//Este é o modulo que salva a conexão com o nosso banco de dados, isso vai ajudar a organização do nosso codigo, alem das coisas que eu falei lá no arquivo de noticias.js

var mysql = require('mysql');

//Nesse caso eu fiz mais algumas modificações nesse arquivo para que ele possa suportar o comomJS

module.exports = function (){

  return mysql.createConnection({
      host: 'localhost',
      user: 'root',
      password : '1234',
      database : 'portal_noticias'
  });//Aqui estamos retornando a conexão com o nosso banco de dados para a classe que requisitar este arquivo.


}

//Ja podemos voltar ao nosso arquivo noticias.js
