//Nesta aula chegou a hora de eliminar aquele negocio chato de ficar entrando no CMD parando o servidor e em seguida rodando ele de novo só por causa de um erro ou de uma pequena modificação que a gente fez. Uma das vantagens de outras linguagens de progra,ção é alterar o arquivo sem precisar compilar assim como é o caso do PHP, e no nodejs nao poderia ser diferente.

//Lembra das aulas anteriores ? Então... ja sabem o que devemos instalar né ?

//Sim é aquele app que se parece com um nome de um digimon, o famoso nodemon, mas antes disso quero fazer algumas considerações!

/*

Nodemon é uma iniciativa para resolver o problema de ficar tendo que parar e executar o servidor novamente para visualizar as alterações, é importante saber que diferente do express, do ejs, o nodemon não é um modulo do nosso projeto ele é um RECURSO DO AMBIENTE DE DESENVOLVIMENTO.

*/

//Para instalar o node certifique-se de que voce esta na pasta do seu projeto no CMD, e sem seguida execute o seguinte comando 'npm install -g nodemon'.

//Para executar o nodemon basta digitarmos dentro da nossa pasta do projeto assim 'nodemon + o script que iremos executar o nosso servidor', o nosso servidor esta aonde pessoal ? Aonde ele esta ?

//Qual o arquivo responsavel por criar o servidor e direcionar os usuarios para suas respectivas paginas assim que ele digita localhost:3000 na url ?

//Isso ai, o app.js

//Para isso basta fazer o seguinte 'nodemon app' e PUMBA! Nodemon rodando que é uma beleza minha gente. Experiemente fazer uma alteração no arquivo e salve... veja que o nodemon ele mostra uma mensagem pra gente no cmd dizendo que ele viu que algo se modificou e em seguida subiu o servidor de novo.


/*

Com isso podemos concluir que o nodemon é uma aplicação automatica que reconhece quando o arquivo é alterado (bem provavel que ele fique verificando de 1 em sem 1 segundo ou menos... ou sei lá mais segundos a data de modificação do arquivo informado pelo sistema operacional ou até mesmo o tamanho) e quando ele identifica isso, ele para o servidor (o sistema faz aquilo que deveriamos fazer... o famoso control + c) e sem seguida starta de novo (o famoso node app.js).

Easy, uma mão na roda não acha... pelo menos já nos livrou de pelo menos 2 processos chatos kkkk (Não precisamos dar mais contro + c e em seguida executar o node pro servidor subir de volta rs)

E sim, esquece esse lance de node app.js, apartir de agora só iremos trabalhar com o nodemon app =)

*/

var express = require('express');

var app = express();

app.set('view engine', 'ejs');

//Agora vamos organizar o nosso codigo um pouco:

app.get('/', function(req, res){
res.render('home/index');
});

app.get('/formulario_inclusao_noticia', function(req, res){
res.render('admin/form_add_noticias');
});

app.get('/noticias', function(req, res){
res.render('noticias/noticias');
});

app.listen(3000, function(){

   console.log("Servidor rodando com o express");

});
