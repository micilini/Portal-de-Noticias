//Esta aulinha aqui vai ser beeeeem simples, tudo o que eu fiz foi adicionar alguns novos subdiretorios e arquivos dentro das views (Isso vai facilitar muito na hora que a gente criar o nosso portal de noticias). Fique tranquilão porque esses arquivos .ejs que estão dentro das views são tudo HTML simples, não tem nada de formulario, nada de css, nada de javascript, nada de imagens nem nada, são só html simples com um texto gigante informando em qual pagina nos estamos.

//Alem disso vamos organizar um pouco mais o nosso codigo! Para assim que digitarmos na URL os endereços o node conseguir jogar a gente para as paginas certas, como estamos fazendo abaixo.

var express = require('express');

var app = express();

app.set('view engine', 'ejs');

//Agora vamos organizar o nosso codigo um pouco:

app.get('/', function(req, res){
res.render('home/index');
});

app.get('/formulario_inclusao_noticia', function(req, res){
res.render('admin/form_add_noticias');
});

app.get('/noticias', function(req, res){
res.render('noticias/noticias');
});

//Show agora nós ja temos o basico pronto =)

app.listen(3000, function(){

   console.log("Servidor rodando com o express");

});
