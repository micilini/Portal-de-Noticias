//Nesta aula iremos aprender a fazer uma comunicação com o banco de dado usando o NODEJS. Antes de mais nada é importante deixar claro aqui, que estou utilizando o windows como sistema operacional, sendo assim eu precisei instalar o mysql na minha maquina (Que é um banco de dados), esse mysql será usado pelo nodejs (No caso de outras linguagens quando tem que instalar o apache no windows ou no linux, voce tambem acaba tendo que instalar o famoso mysql na sua maquina). E aqui no caso do NODEJS não vai ser diferente, sendo assim tive que instalar o servidor do mysql na minha maquina. Para isso tive que acessar o site: https://www.mysql.com/ e ir mais especificamente nesta URL baixar o instalar para windows: https://dev.mysql.com/downloads/windows/installer/ e tive que baixar o seguinte "Windows (x86, 32-bit), MSI Installer	5.7.21	370.8M" que representa o instalador do mysql.

//Apos o download feito, foi necessario instalar o mysql no windows selecionando a opção 'server only', em seguida só precisei dar next em tudo e definir uma senha que no meu caso foi '1234' e pronto!

//No meu mysql eu precisei criar um banco de dados chamado portal_noticias e dentro dele uma tabela chamada noticias com os seguintes campos: create table noticias (id_noticia int not null primary key auto_increment, titulo varchar(100), noticia text, data_criacao timestamp default current_timestamp);

//E dentro dessa tabela inseri um unico registro: insert into noticias (titulo, noticia)values('titulo da noticia', 'conteudo da noticia');

//Perfeito, agora voltando ao objetivo desta aula, nos queremos que assim que o usuario acesse 'localhost:3000/noticia' apareca o conteudo salvo no nosso banco de dados que no caso são os valores existentes dentro da nossa tabela (Nesta aula vamos mostra-lo de uma maneira beeem simples mesmo em formato json mesmo, nada muito bonito ou muito top).

//Precisamos de uma conexão com o banco de dados, mas o principal foco desta aula não esta nesse arquivo, portanto te espero no arquivo noticias.js existentes dentro da pasta app > routes... Te aguardo lá =)

var app = require('./config/server');

var rotaHome = require('./app/routes/home')(app);

var rotaNoticias = require('./app/routes/noticias')(app);

var rotaFormInclusaoNoticia = require('./app/routes/form_inclusao_noticia')(app);

app.listen(3000, function(){
    console.log("Servidor ON");
});
