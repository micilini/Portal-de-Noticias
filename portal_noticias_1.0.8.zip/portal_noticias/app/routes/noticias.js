module.exports = function(app){
    app.get('/noticias', function(req,res){

        //Como nós queremos que assim que o usuario entre na aba de noticias do nosso portal (localhost:3000/noticias) apareca os dados salvos no nosso banco de dados, devemos escrever toda a loja de comandos aqui dentro do app.get!

        //A primeira coisa que devemos fazer para pegar tais dados, é estabelecer primeiro uma conexão com o nosso banco de dados MYSQL, como na aula anterior vimos como instalar o modulo que faz essa comunicação, já sabemo que tal modulo existe dentro de node_modules, então basta darmos aquele nosso require ;)

        var mysql = require('mysql');//Pega o modulo de MYSQL que acabamos de instalador

        //Bom, já temos a instancia do modulo capaz de fazer comunicações com o nosso banco de dados instalado localmente na nossa maquina (No meu windows, não sei se voce utiliza windows tbm rs)

        //Agora chegou a hora de entrar nesse banco de dados, informando o usuario, o local dele, e a famosa senha que eu configurei lá atras no instalador de mysql para windows (1234). Para isso devemos pegar a instancia do mysql e usar a função chamada 'createConnection' e dentro dela informar alguns dados como host, user, password e database.

        var connection = mysql.createConnection({//Pegamos a instancia do mysql e criamos uma conexão com o banco de dados
            host: 'localhost',//Informamos o host que queremos nos conectar, como o banco de dados esta instalado na nossa maquina e este arquivo tbm esta na nossa maquina, devemos informar localhost, se o banco de dados estivesse em outro servidor (ou queiramos acessar um outro banco de dados que não seja o nosso) deveriamos colocar o endereço de IP aqui no local de 'localhost'
            user: 'root',//Aqui informamos o usuario do nosso banco de dados, que por padrão é o 'root' (Sim da pra criar e utilizar outros usuarios, mas na configuração do banco de dados não cheguei a configurar este tipo de coisa)
            password : '1234',//Esta é a senha que definimos para o nosso usuario root durante a instalação do banco de dados
            database : 'portal_noticias'//E por fim o banco de dados que queremos utilizar que no caso é o portal_noticias (se quisermos utilizar outro banco de dados é so informar o nome dele aqui)
        });

        //Depois da nossa conexão precisamos agora puxar aquelas informações das noticias que salvei no banco de dados, para isso devemos pegar a variavel que tem a conexão com o banco de dados e utilizar o comando chamado 'query':


        /*

        connection.query(<sql>, <função de callback>);

        A função query ela espera duas coisas:

        <sql> -> O sql é a consulta em si, ou seja, falo que sistema ir na tabela tal e me retornar a informação tal

        <função de callback> -> É o que vai ser feito após a consulta ser realizada, voce pode pensar nisso como uma função que precisa ser executada assim que a gente puxa um modulo (como estamos fazendo no nosso curso). Dentro do node voce vai ver que as estruturas funcionam muito com callback, e as funções de callback é que dão pro node uma caracteristica muito particilar e uma vantagem muito grande uma vez que em uma função de uma outra linguagem... vamos tomar como o exemplo a linguagem PHP, nós fariamos a consulta e a nossa aplicação iria esperar o resultado da consulta para então fazer alguma coisa, na função de callback do node ele dispara a consulta e QUANDOOOOOOOO ela finalizar ele retorna pra gente uma informação sem travar a a aplicação, o que nos possibilita continuar usando a aplicação.

        No caso da função de callback ela espera dois parametros:

        function(error, result){


       }

       O erro é quando retornar alguma erro na query, e o result é o resultado desta query, que no caso serão os registros salvos no nosso banco de dados.

       Então vamos colocar a mão na massa.

        */

        connection.query('select * from noticias', function(error, result){//estamos fazendo uma conexão com o banco de dados enviando uma query que diz para puxar todos os dados existentes dentro daquela tabela chamada noticias, e do outro lado estamos com uma função de callback que a gente ja sabe como funciona.

        res.send(result);//Assim que o banco de dados nos retornar uma resposta a gente vai printar na tela, para isso estamos pegando a variavel RES (que sabemos pra que funciona) ela esta declarada na linha 2, e esta relacionada ao app.get (consegue se lembrar ?). Estamos enviando o conteudo da variavel result que como dito acima ele '...  result é o resultado desta query, que no caso serão os registros salvos no nosso banco de dados. ...'.

        //Tenha em mente que os registros no banco de dados serão retornados no formato JSON assim como a maioria das requisições em outros modulos, JSON é um formato universal que muitas pessoas usam para trocar ou enviar informações isso porque ele é bem simples de ser entendivel tanto para a maquina quanto para nós usuarios (Ele é tipo uma especie de array).

        });


        //res.render('noticias/noticias');//Vamos desativar isso aqui por enquanto... só queremos ver o resultado do registros existentes no nosso banco de dados.

        //Perfeito, agora rodaremos o nosso codigo 'nodemon app' (dentro da pasta do nosso projeto é claro) e sem seguida abriremos a URL 'localhost:3000/noticias'
    });
}
