//Aqui nos vamos criar o nosso servidor utilizando o NODEJS, so que dessa vez iremos fazer isso usando o express que é o nosso modulo capaz de executar e tratar arquivos html da melhor forma, lembre-se que o express é uma camada um pouco acima do NODEJS.

var express = require('express');//Pegamos a instancia do modulo express

//Em seguida precisamos executra a função que esta contida dentro do framework express, da seguinte forma:

var app = express();//Esta função meio que liga o modulo do express para futuramente começarmos a fazer outras coisas, se a gente não ligar, nada poderá ser feito.

//Essas duas linhas de codigos acima poderiam ser feitas somente com uma unica linha dessa forma "var app = require('express')()" saiba que o segundo parentesis tem a mesma função de usar o express(); como fizemos na nossa linha acima

app.listen(3000, function(){//No caso do express basta a gente chamar o metodo listen que ele ja fica escutando requisições da porta 3000 (Diferente do http createServer)

   console.log("Servidor rodando com o express");//Para verificar se o nosso servidor esta funcionando, basta a gente rodar no CMD 'node app.js' e abrir a url (localhost:3000) no nosso navegador!

});

//Assim que executar esse projeto no CMD, vamos ver que o consolelog rodou, mas apareceu uma mensagem dizendo assim 'cannot GET /', isso aconteceu porque diferente do HTTP, o express ele consegue identificar que não existe nenhum caminho (nenhuma pagina ou resposta) para ser dada assim que o usuario acessa localhost:3000.

//Para resolver isso, devemos informar este tipo de coisa para o express, veremos isso na nossa segunda aula.
