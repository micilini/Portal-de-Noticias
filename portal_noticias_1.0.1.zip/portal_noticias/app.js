//Aqui nos vamos criar os caminhos para o express reconhecer na URL (assim como falamos na aula anterior).

var express = require('express');

var app = express();

//Para resolvermos aquele problema de cannotget devemos criar as nossas rotas, no caso do expressa elas são feitas da seguinte forma:

app.get('/', function(req, res){//Funciona da mesma forma como vimos nas aulas anteriores, sendo que noe express devemos usar a função get e infomar duas coisas 'O caminho', que neste exemplo estamos pegando o caminho normal (então quando o usuario digitar localhost:3000) ele vai cair aqui. E a outra função de callback que sabemos como funciona que no caso retorna o request e o response.

res.send('<html><body>Portal de Noticias</body></html>');//Aqui pegamos a resposta e enviamos com o comando send (ele é a mesma coisa que o comando end do modulo de http).

//Sendo assim quando iniciarmos o servidor e colocarmos 'localhost:3000' será mostrado portal de noticias na nossa tela.


});

app.get('/tecnologia', function(req, res){
    res.send('<html><body>Categoria de Tecnologia</body></html>');  //Aqui fiz um outro exemplo, se digitarmos na url 'localhost:3000/tecnologia' ele vai cair aqui e será mostrado no nosso navegador 'Categoria de Tecnologia'.
});

app.listen(3000, function(){

   console.log("Servidor rodando com o express");

});

//Veja que a estrutura do codigo ficou mais simples do que implementar todas as URL'S COM IF E ELSE quando fizemos utilizando o modulo de http.
