module.exports = function(app){

    app.get('/noticias', function(req,res){

        var connection = app.config.dbConnection();
        var noticiasModel = app.app.models.noticiasModels;//Como explicado no ultimo arquivo, aqui estamos instanciando o modulo de models aonde vai estar o nosso codigo do banco de dados.

        //Para que a logica funcione devemos chamar a função getNoticia aqui como foi explicado no ultimo arquivo:

        noticiasModel.getNoticias(connection, function(error, result){//estamos chamando a variavel que contem a instancoa de noticiasmode e em seguida chamados a função getNoticias, e por fim enviamos os 2 parametros, um que é a conexão com o banco de dados e o outro que é o nosso callback!
        res.render("noticias/noticias", {noticia : result});
        });

        //E qual que é a boa aqui ? A boa é que em qualquer lugar do nosso codigos caso quisermos pegar as noticias basta chamarmos o noticiaModels e em seguida a função getNoticias =)

        //Com isso o futuro programador nao precisa saber como o getNoticias funciona, ele simplesmente entende que esse codigo retorna uma noticia e pronto, agora caso ele queira entender mais a fundo e quem saiba modificar basta ele entrar no arquivo para ver e fazer as suas devidas alterações.

        //E pronto, o nosso codigo vai funcionar como antes! É claro precisamos fazer a mesma coisa no arquivo noticia.js

    });
}
