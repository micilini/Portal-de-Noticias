module.exports = function(app){

    app.get('/noticia', function(req,res){

        var connection = app.config.dbConnection();


       //Mesma logica do noticias.js so que neste arquivo nós estamos chamando o mesmo model so que uma função diferente e enviando um callback diferente!

        var noticiaModel = app.app.models.noticiasModels;

        noticiaModel.getNoticia(connection, function(error, result){
        res.render("noticias/noticia", {noticia : result});
        });

    });
}
