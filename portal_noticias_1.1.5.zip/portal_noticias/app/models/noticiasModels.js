//Aqui dentro deste arquivo a logica é a mesma, precisamos criar um modulo que exporte as consultas do banco de dados na tabela de noticias, então vamos lá:

module.exports = function(){//Este codigo já sabemos como ele é feito

  //Agora é o seguinte:

  /*

  Vamos estruturar esse codigo da seguinte forma, lá no noticias.js aonde TINHA aquele codigo que faz a consulta com o banco de dados, então esse codigo nao pode estar mais lá, esse codigo ele deve ficar por aqui!

  Sendo assim vamos fazer o seguinte, vamos criar uma função aqui dentro desse modulo e vamos chama-la de getNoticias.

  Perfeito, essa função ela tem que receber duas coisas.

  Primeiro para que a gente faça a comunicação com o banco de dados devemos receber uma instancia do dbConnection.
  Segundo precisamos pegar aquela função de render que chama a view e tudo mais... Sim ela precisa estar aqui dentro desse arquivo pois ela é um callback.



  */

  this.getNoticias = function(connection, callback){//E foi exatamente isso que fizemos aqui com essa nova função
      connection.query('select * from noticias', callback);//Agora basta pegarmos a variavel chamada connection que declaramos acima (e que esperamos que venha uma instancia do banco de dados), e por fim recebemos aquele nosso callback ou seja esperamos receber este comando abaixo:

      /*

      function(error, result){

      res.render("noticias/noticias", {noticia : result});

      });

      Porque se recebermos ele dentro da nossa variavel esse codigo que é assim:

      connection.query('select * from noticias', callback);

      Ficaria assim:

      connection.query('select * from noticias', function(error, result){

      res.render("noticias/noticias", {noticia : result});

      });

      Ou seja, a mesma coisa que fizemos no noticias.js!

      */
  }

  //Este codigo tem a mesma logica do codigo acima (Veja se voce consegue entender), a diferença é que ele vai servir pro arquivo noticia.js que pega uma noticia especifica e mostra pra gente

  this.getNoticia = function(connection, callback){
      connection.query('select * from noticias where id_noticias = 1', callback);
  }

  //Perfeito, tudo bonito e tudo lindo, agora precisamos retornar tudo isso pro noticias.js e noticia.js que serão os locais para onde esses arquivos serão chamados para isso iremos fazer o return this.

  //No caso esse this, ele vai retornar as funções para dentro da variavel aonde ele for chamado, com isso basta a gente fazer o seguinte comando: 'var = noticiasModels = app.app.models.noticiasModels' para instanciarmos esta classe e em seguida usar a função da seguinte forma 'noticiaModels.getNoticias' e continuar com nosso codigo (Como veremos nos arquivos noticias.js e noticia.js)

  return this;

  //Beleza agora vamos direto para o arquivo noticias.js te encontro lá

}
