//Nesta aula novamente! Iremos organizar o nosso codigo hahaha

//Serio, talvez você que esteja vendo isso esteja achando bem chato, mas é necessario aprendermos isso minha gente!

//Nesta aula a gente vai aprender a como podemos implementar os MODELS, os famosos models existentes dentro de uma estrutura MVC.

/*

Para aqueles que não sabem models representam entidades do nosso banco de dados, em outras palavras cada model vai controlar ai uma tabela da nossa aplicação. Com isso a gente consegue separar toda a logica de dados da propria aplicação, então a gente consegue deslocar uma parte da nossa regra de negocios para dentro da nossa estrutura de models.

Assim a gente torna ainda mais os nossos codigos reutilizaveis.

Enfim, essa foi a explicação do professor, agora vamos a minha propria explicação... o que são models ?

Lembra que no inicio desse projeto dentro do app.js a gente tinha codigos html juntos com codigos de rota ? Lembram ? E o que a gente fez ?

A gente separou os codigos de rota em um canto, e os codigos html em outro e com isso eu mostrei os beneficios a voces!

Os codigos html ficam em um canto chamado view!

Agora nos vamos criar um outro canto chamado models!

Esse canto (do models) vai servir para guardar todos os arquivos javascript (.js ou chame de modulos) que fazem uma requisição no nosso banco de dados. Ou seja, a gente nao separou o codigo html do codigo de rotas ? Então... se voce perceber no modulo chamado noticias.js ou noticia.js lá dentor tem um codigo de faz uma requisição no banco de dados, correto ?

Sim correto, no MVC isso não pode ficar Assim, porque todo e qualquer tipo de comando que trabelhe com o banco de dados deve ser criado um modulo especifico dentro da pasta models aonde tenha esses codigos!

Sendo assim os arquivos que precisarem fazer algo no banco de dados devem requisitar esses modulos que estão dentro da pasta models!

E é isso!

Então é interessante separar este tipo de coisa, porque geralmente esses comandos de banco de dados a gente só chama, insere, atualiza, ou deleta alguma dados especifico, e com isso a gente pode separa-los em um outro arquivo o que facilita tambem a manutenção do mesmo. (Dessa forma a gente nao precisa ficar repetindo consultas em telas que são muito parecidas).

Então vamos lá a primeira coisa que devemos fazer é criar uma nova pasta chamada 'models' dentro do nosso projeto mais especificamente dentro da pasta app (de maneira que fique no mesmo nivel das pastas views e routes).

E dentro dessa pasta vamos criar um arquivo que vai representar a nossa entidade da nossa tabale que é a tabela de noticias, então todo o codigo de inserir novas noticias, atualizar, pegar noticias, ou deletar deverão estar dentro desse modulo especifico (E não mais dentro das nossas rotas), vou chamar este arquivo de 'noticiaModels.js'.

Agora precisamos ir no arquivo 'server.js' e dizer ao consign para que ele carregue todos os arquivos existentes dentro da pasta models (Isso pra dentro dos arquivos de rotas não precisarmos dar um require dos arquivos que estarão em models).

Perfeito, agora podemos ir direto pro arquivo noticiasModels.js te encontro lá

*/

var app = require('./config/server');

app.listen(3000, function(){
    console.log("Servidor ON");
});
