//nesta aula precisamos arrumar uma coisa pequena, sabe quando a gente preenche o formulario e deixa de preencher por exemplo um unico campo e dai o sistema retorna um erro ?

//Então... se voce perceber ali tem um problema! Tudo o que tinhamos digitado anteriormente simplesmente SOME!

//Mas fique tranquilo que esse problema é plausivel de ser resolvido, para resolver ele vamos dar uma olhada no arquivo admin.js

var app = require('./config/server');

app.listen(3000, function(){
    console.log("Servidor ON");
});
