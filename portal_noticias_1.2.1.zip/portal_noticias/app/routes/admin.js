module.exports = function(app){
    app.get('/formulario_inclusao_noticia', function(req,res){
        res.render('admin/form_add_noticia', {'validacao' : {}, 'noticia' : {}});//Não se esqueca de passar o parametro noticia pra cá, isso vai evitar alguns problemas!
    });


    app.post('/noticias/salvar', function(req,res){
        var noticia = req.body;

        req.assert('titulo', 'Titulo é obrigatorio').notEmpty();
        req.assert('resumo', 'Resumo é obrigatorio').notEmpty();
        req.assert('titulo', 'Resumo deve conter entre 10 e 100 caracteres').len(10, 100);
        req.assert('autor', 'Autor é obrigatorio').notEmpty();
        req.assert('data_noticia', 'Data é obrigatorio').notEmpty().isDate({format: 'YYYY-MM-DD'});
        req.assert('noticia', 'Noticia é obrigatorio').notEmpty();

        var erros = req.validationErrors();

        if(erros){
         res.render('admin/form_add_noticia', {'validacao' : erros, 'noticia' : noticia});//Para que funcione basta a gente enviar tambem no nosso JSON os valores que foram retornados pela noticia!
         return;
        }

        //Para que funcione devemos ir no nosso formulario no arquivo form_add_noticia.ejs


        var connection = app.config.dbConnection();
        var noticiasModel = new app.app.models.NoticiasDAO(connection);

        noticiasModel.salvarNoticia(noticia, function(error, result){
        res.redirect("/noticias");
        });


    });

}
