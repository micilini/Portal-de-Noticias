//Agora vamos instalar o modulo de conexão com o banco de dados chamado MYSQL, ter uma banco de dados ajuda a gente armazenar alguns dados, como textos, nomes, logins, senhas e outras informações revelantes que serão muito uteis para o nosso portal de noticias futuramente.

//Para instalar o banco de dados, vamos ter que abrir o nosso prompt (Não se esqueca de estar dentro da sua pasta de arquivos no meu caso eu estou dentro de portal_noticias, entrei com o comando do windows 'cd C:/portal_noticias'). Em seguida basta executar o seguinte comando no prompt 'npm install mysql --save' com este comando a gente vai conseguir baixar um modulo de conexão com o banco de dados no nodejs.

//Antes de mais nada devemos entender que o javascript puro é uma linguagem do lado do cliente! E não é possivel fazer conexão com o banco de dados. Maaaaaaaaaas estamos utilizando o node, e como sabemos ele é uma linguagem do lado do clientes mas que consegue fazer comunicações com o lado do servidor atraves de uma outra linguagem (Mas não precisamos entender esta linguagem... só precisamos entender javascript =) )

//Se a gente entrar na pasta node_modules já conseguiremos identificar a pasta mysql e isso diz a respeito de que ele esta instalado (Mesma coisa se acessarmos o package.json veremos que existe uma dependencia chamada mysql lá)

var app = require('./config/server');

var rotaHome = require('./app/routes/home')(app);

var rotaNoticias = require('./app/routes/noticias')(app);

var rotaFormInclusaoNoticia = require('./app/routes/form_inclusao_noticia')(app);

app.listen(3000, function(){
    console.log("Servidor ON");
});
