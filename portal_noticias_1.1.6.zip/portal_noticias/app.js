//Nesta aula o nosso objetivo vai ser criar o formulario de inclusão de noticias, finalmente aquele arquivo form_inclusao_noticia.js vai funcionar =)

//Então basicamente vamos para o arquivo chamado form_add_noticia.ejs localizado dentro de app > views > admin

//Beleza, depois de ter criado o nosso formulario em formato HTML podemos continuar com a nossa logica!

/*

Então vamos lá como voce mesmo view dentro do arquivo form_add_noticia.ejs, estamos enviando aqueles dado para uma nova URL chamada /noticias/salvar. E como voce mesmo sabe, isso é uma rota e atualmente não existe nenhum arquivo para ela (Bem quando eu estava escrevendo nao existia, mas eu criei kkk). Então a primeira coisa que devemos fazer é criar esta rota.

Mas por questões de organizaçaões vamos fazer o seguinte, sabe o arquivo form_inclusao_noticia.js ? Vamos alterar o nome dele para admin.js uma vez que o html que contem o formalario esta dentro de uma pasta chamada admin e não vai ser qualquer um que poderá acessa-la, resolvi mudar o nome do arquivo lá.

Perfeito, agora te espero dentro desse arquivo (admin.js) para mais instruções!

*/

var app = require('./config/server');

app.listen(3000, function(){
    console.log("Servidor ON");
});
