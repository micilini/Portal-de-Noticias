module.exports = function(app){
    app.get('/formulario_inclusao_noticia', function(req,res){
        res.render('admin/form_add_noticia');
    });

    //Ok, dentro desse arquivo ficará todas as rotas que um administrador poderá fazer no sistema, mas por agora só queremos adicionar a rota que o usuario faz quando clica em enviar formulario (afim de salvar os dados no banco de dados).

    //A primeira coisa que devemos entender é que para criar uma nova rota usamos o app.get, ou seja usamos o metodo de requisição get, que nada mais é do que um metodo comum quando a gente coloca uma nova url no navegador.

    //Só que no nosso formulario esta diferente, estamos dizendo que os valores que serão enviados para a rota salvar serão do metodo post, nesse caso, se colocarmos app.get + a rota do salvar o node nao vai reconhecer, para que ele reconheca devemos cadastrar o metodo de requisição certo que é o post dessa forma: app.post como devemos abaixo:

    app.post('/noticias/salvar', function(req,res){

        //Agora precisamos recuperar as informações do formulario ou seja, precisamos pegar todos os textos que o usuario digitou tanto no campo de titulo quanto no campo de conteudo da noticia, para isso podemos pegar a variavel req que armazena a resposta vinda pelo navegador do usuario e selecionar o body que é o corpo da mensagem (local aonde fica armazenado a requisição que foi trazida pra cá, ou seja os textos separados em formato JSON).

        var noticia = req.body;
        res.send(noticia);

        //E perfeito, agora nos estamos conseguindo puxar os dados e estamos utilizando o send para mostrar os dados que foram tradidos em foprmato JSON =)

        //MENTIRA!

        //Na verdade não veio nada, sabe porque ?

        //Porque precisamos de um modulo capaz de tratar essas requisições, o express não é capaz de tratar isso pra gente, sendo assim precisamos abrir o prompt (para o servidor caso ele esteja rodando) entrar na pasta do projeto e executar o seguinte comando para instalar o modulo chamado body-parser: 'npm install body-parser --save'. Após a instalção nao se esqueça de subir o servidor novamente com comando 'nodemon app'.

        //Perfeito, agora temos que adicionar o modulo do body-parser para dentro do express para que ele consiga tratar as informações que precisamos, te encontro no arquivo server.js
    });

}
