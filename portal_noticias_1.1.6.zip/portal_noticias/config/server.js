var express = require('express');
var consign = require('consign');
var bodyParser = require('body-parser');//Primeiro devemos incluir o nosso modulo de body-parser como fizemos como o express e consign

var app = express();
app.set('view engine', 'ejs');
app.set('views', './app/views');

//Logo após a inclusão devemos adiciona-lo ao modulo do express da seguinte forma:

app.use(bodyParser.urlencoded({extended : true}));//Aqui estamos usando o parametro use do express que diz que vamos utilizar um modulo adicional, por fim usamos o bodyparser informando algumas parametros da URL (sim podemos informar outros parametros ali dentro tbm).

//E é isso podemos acessar a URL 'http://localhost:3000/formulario_inclusao_noticia' e pronto, podemos escrever ali e clicar em enviar que na outra tela iremos ver a mensagem em formato JSON (Não é mais mentira, AGORA É VERDADE!)

consign()
      .include('app/routes')
      .then('config/dbConnection.js')
      .then('app/models')
      .into(app);

module.exports = app;
