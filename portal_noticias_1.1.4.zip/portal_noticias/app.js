//Nesta aula vamos aprender a criar os detalhes das noticias, essa aula tambem vai servir para que a gente possa se familiarizar ainda mais com esse modelo de design pattersn e voce verá como é muuuuuito fácil criar novas views =)

//Sabe aquele arquivo chamado noticia.ejs que criamos e até agr não trabalhamos com ele ? Então vamos usar ele nesta aula. Mas para que ele funcione e gente precisa criar uma rota para ele, pois se a gente for no navegador e digitar 'localhost:3000/noticia' vai dar erro de cannotget.

//Então vamos lá, precisou criar uma nova view ? Uma nova rota ? Basta a gente ir em routes e criar um novo arquivo, no meu caso vou criar com o nome de noticia.js (No meu caso eu copiei todos os codigos de noticias.js para noticia.js e modifiquei algumas coisas)

//Apartir deste momento, se a gente for executar na URL 'localhost:3000/noticia' veremos que ele já consegue reconhecer que existe uma rota pra ela.

//De uma olhada nos arquivos noticia.js e noticia.ejs

//E pronto os detalhes das noticias ja esta funcionando, e voce apartir de agora ja sabe como criar novas rotas não ? 

var app = require('./config/server');

app.listen(3000, function(){
    console.log("Servidor ON");
});
