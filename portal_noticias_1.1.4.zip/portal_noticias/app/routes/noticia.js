module.exports = function(app){

    app.get('/noticia', function(req,res){//Essa rota é do noticia!

        var connection = app.config.dbConnection();

        connection.query('select * from noticias where id_noticias = 1', function(error, result){//Como aqui queremos pegar um detalhe de somente uma unica noticia usamos este comando do SQL

        res.render("noticias/noticia", {noticia : result});

        });

    });
}
