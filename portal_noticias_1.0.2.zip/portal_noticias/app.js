
//Nesta aula iremos instalar o EJS e importa-lo para dentro do nosso projeto, ele é um modulo que vai nos permitir escrever paginas HTML juntamente com instruções javascript. Tecnicamente falando, ele é um engine de views que vai permitir a criação de paginas HTML dinamicas.

//Com o EJS, não iremos mais precisar usar o html como fizemos no comando de send na outra aula -> "res.send('<html><body>Portal de Noticias</body></html>');", apartir de agora vamos criar arquivos html em pastas e locais separados e vamos meio que chama-los para dentro do nosso projeto. isso vai nos ajudar bastante, porque pensa comigo ? E se eu tiver uma pagina HTML com mais de 1.000 linhas de codigo ? Iria ficar ruim para visualizar o codigo do layout e o codigo do sistema, não acha... por isso é bom separar, codigo de sistema fica em um canto, codigo de layout fica totalmente em outro e os 2 não se misturam (Se misturam sim, mas é bem basico, veremos isso futuramente, quando precisaremos enviar parametros processados pelo node para o nosso layout).

//A primeira coisa que devemos fazer é instalar o modulo de EJS, portanto abra o CMD, entre na pasta do seu projeto, e execute o seguinte codigo: "npm install ejs --save". Assim que a instalção terminar o EJS estará disponivel dentro da nossa pasta de projetos, mais especificamente dentro de node_modules, será criada uma pasta nova chamada 'ejs'.

//Agora com o EJS instalado precisamos informar ao express que o engine de views (o modulo responsavel por renderializar os codigos html e afins) não será mais o modulo padrão do express mas sim o modulo do EJS que acabamos de instalar. Para isso devemos modificar a tabela de propriedades do express, esse tipo de coisa da para ser feita via codigo de programação como vamos ver abaixo:

var express = require('express');

var app = express();

//Agora vamos alterar a tabela de propriedades do express para ele usar o EJS, para isso temos que ja ter a classe do express instanciada como fizemos acima, em seguida basta utilizar a função set e passar os parametros.

app.set('view engine', 'ejs');//'view engine' é a propriedade do express que iremos alterar, essa propriedade armazenava o valor padrão de views do express, mas como agora queremos utilizar o ejs, a gente informa ali o ejs depois da virgula o que indica que a propriedade view engine vai armazenar o valor ejs, e quando o sistema rodar ele vai passar a trabalhar com o modulo do ejs.

//E como eu disse acima 'Arquivos de layout pra um lado, arquivos do sistema para o outro', vamos agora separar os arquivos do nossos sistema dos arquivos de layout. Para isso e por padrão a gente deve criar uma pasta dentro do nosso diretorio chamada 'view' (dentro da pasta do nosso portal_noticias de forma que fique do lado da pasta node_modules e do arquivos app.js).

//Dentro dessa pasta podemos criar subdiretorios e de fato os nossos arquivos HTML, o mais interessante é que como estamos utilizando o EJS, nos podemos criar arquivos com a extensão .ejs e dentro deles podemos trabalhar tanto com codigos html tanto com codigos javascript.

//Como o nosso portal de noticias vai ter varias seções, ou seja, seção quando a gente abre a pagina principal (localhost:3000) e lá vai aparecer a home page, seção de tecnologia (localhost:3000/tecnologia) e lá vai aparecer assuntos relacionadas a essa area, é bom a gente organizar as coisas. Portanto eu criei 2 pastas dentro de views, uma chamada 'home' aonde vai ter a noss homepage (ou pagina inicial se voce preferir), e a outra chamada 'secao' que vai armazenar os layouts das paginas de tecnologia, beleza e afins.

//Dentro de cada uma das pastas foi criado um arquivo html beeeem simples (como estamos fazendo inline nas outras aulas).


app.get('/', function(req, res){

//Como estamos utilizando o EJS, precismos fazer algumas modificações aqui, enquanto no express o modulo padrão de views precisaria usar o comando send, no EJS a gente usa o comando render, e dentro dele podemos informar o caminho do arquivo .ejs

res.render('home/index');//Aqui voce percebeu que a gente não precisou informar o caminho completo ou seja utilizar o 'view' antes de tudo (ex: 'view/home/index.ejs'), uma vez que o EJS ele já procura automaticamente essa pasta views, por isso ela é tão importante, ela não é só um padrão de projetos no node mas tambem em outras linguagens que utilizam o design pattern conhecido como MVC (Model View Controller). outro ponto importante é que caso o arquivo for do tipo .ejs não precisaremos informar index.ejs pois o render automaticamente já reconhece, ah nao ser que voce tenha um arquivo .html ou outra extensão (Uma vez que por padrão o ejs procura por essas extenções).

});

//Abaixo fizemos um outro exemplo utilizando a seção de tecnologia como falamos no inicio dessa aula

app.get('/tecnologia', function(req, res){

res.render('secao/tecnologia');//A seção de tecnologia esta dentro da pasta secao (como criamos acima).

});


app.listen(3000, function(){

   console.log("Servidor rodando com o express");

});

//Na proxima aula ja colocaremos a mão na massa, sendo assim, voce vai ver novos arquivos e subdiretorios dentro da pasta 'views', mas é tranquilo não existem codigos nele, somente layouts html, fizemos isso para economizar tempo =)
