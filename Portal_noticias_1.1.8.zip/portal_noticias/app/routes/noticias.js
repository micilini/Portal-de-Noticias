module.exports = function(app){

    app.get('/noticias', function(req,res){

        var connection = app.config.dbConnection();
        var noticiasModel = new app.app.models.NoticiasDAO(connection);//Agora isso aqui é uma classe sendo assim precisamos chamar ela com o comando new, estamos abrindo realmente uma instancia dessa função e trabalhando dentro dela. Veja que precisamos passar o connection como parametro para a nossa classe!

        noticiasModel.getNoticias(function(error, result){//Veja que o parametro connection foi retirado da função
        res.render("noticias/noticias", {noticia : result});
        });


    });
}
