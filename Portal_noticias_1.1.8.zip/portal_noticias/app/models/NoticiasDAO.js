function NoticiasDAO(connection){//Aqui nos criamos uma classe (que na verdade é uma função uma vez que o javascript nao suporta classe, diferentemente de outras linguagens que suportam)

  //Voce eprcebeu que ali dentro da nossa classe estamos recebendo uma variavel chamada connection na verdade ela esta ali para receber a conexão com o banco de dados, visto que existia muita repetição de codigo dentro das nossas funções (lembra que eu tinha que usar o connection junto com o callback ? Pois bem, agora so precisa do callback, exceto o salvarNoticia que precisa dos valores para serem inseridos no banco de dados).

  //Mas para que a ideia funcione eu preciso criar um atributo dentro dessa nossa classe que pegue o valor connection vindo pela classe para isso posso fazer o seguinte:

  this._connection = connection;//Isso aqui foi criado porque ele será usado dentro das nossas funções que iremos definir abaixo. O underline diz que a variavel em questão faz parte da nossa classe!

}

//Como a função acima agora é uma classe, precisamos definir seus proprios metodos, para isso o proprio javascript possui um comando chamado prototype, mas o que ele realmente faz ?

/*

Segundo a W3c: A propriedade protótipo JavaScript permite que você adicione novas propriedades aos construtores de objetos:

Ou seja, é possivel adicionar novas variaveis para dentro daquela nossa classe ali em cima, adicionar novas funções, e novos metodos.

Então para quesitos de organização resolvemos utilizar o prototype para isso.

*/

NoticiasDAO.prototype.getNoticias = function(callback){//Aqui nos estamos dizendo o seguinte, javascript selecione a classe (função) noticias que criamos acima e adicione uma nova função lá dentro (prototype) chamada get noticias... Bem de resto voce ja deve saber como funciona.


//Agora uma breve observação ? Poderiamos simplesmente pegar essa noticia e adicionar dentro da nossa classe que criamos acima ? Sim nós podemos para isso poderiamos fazer o seguinte codigo:

/*

function NoticiasDAO(){

this.getNoticia = function(){}

}

Mas preferimos fazer assim pois fica mais organizado e o mercado de trabalho por quesitos de design pattern tambem esta fazendo isso, e se voce for parar para analisar é bem melhor fazer assim beeem separadinho do que sair tacando um monte de funções dentro de uma unica classes. Alem de ficar muito mais intuitiva!

*/

    this._connection.query('select * from noticias', callback);//Estamos utilizando aqui o this._connection o que faz referencia a nossa propriedade que declaramos na nossa classe!
}

NoticiasDAO.prototype.getNoticia = function(callback){//Observe que não precisamos mais da variavel connection aqui...
    this._connection.query('select * from noticias where id_noticias = 1', callback);
}

NoticiasDAO.prototype.salvarNoticia = function(noticia, callback){//connection aqui tbm não..
      this._connection.query('insert into noticias set ?', noticia, callback);
}

module.exports = function(){
  return NoticiasDAO;//Por fim basta a gente retornar a nossa classe de NoticiasDAO atraves do module.exports como estamos fazendo desde o inicio deste curso!
}

//Para finalizar, agora que criamos uma nova vlasse a chamada deve se dar de uma maneira um pouco diferente, se voce for nos arquivos como noticias.js voce vai ver que a chamada foi feita de uma forma diferente, assim como outros arquivos que tambem trabalham com esse model como noticia.js e admin.js.

//É interessante que o nosso arquivo tenha o mesmo nome da nossa classe, sendo assim e como estamos utilizando o DAO, eu renomieie os arquivos e as classes (Tive que fazer isso tambem em: noticias.js noticia.js e admin.js pois estavam com nomes antigos)

//Dê uma olhada em cada um deles para possiveis esclarecimentos sobre como funciona esse novo metodo que estaos chamando.
