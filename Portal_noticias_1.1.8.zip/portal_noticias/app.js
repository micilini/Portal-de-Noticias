//Nesta aula nos vamos organizar o model de noticiasModels.js para que ele utilize classes no javascript, então fiquei ligado nessa aula porque vamos aprender muita coisa nova nela =)

//Ao transformarmos o nosso model noticiasModels em uma determinada classe nos iremos ganhar em duas frentes: primeiro que estamos colocando ai um design pattern chamado DAO (data access object) o que criaremos um modelo de trabalho que é bastante comum no mercado, em contra partida teremos que usar instancias (new) o que não teremos mais problemas para sobreescrever variaveis em função do escopo da variavel que estivermos trabalhando.

//Então vamos para o nosso antigo arquivo chamado noticiasModels.js que agora se chama noticiasDAO.js...

var app = require('./config/server');

app.listen(3000, function(){
    console.log("Servidor ON");
});
